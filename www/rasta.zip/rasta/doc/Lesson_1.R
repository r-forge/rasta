### R code from vignette source 'Lesson_1.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: preliminaries
###################################################
options(width = 80, prompt = "> ", continue = "+ ")


###################################################
### code chunk number 2: Lesson_1.Rnw:220-222
###################################################
rm(list = ls())  # Clear the workspace!
ls() ## no objects left in the workspace


###################################################
### code chunk number 3: Lesson_1.Rnw:226-228
###################################################
a <- 1
a


###################################################
### code chunk number 4: Lesson_1.Rnw:240-241
###################################################
class(a)


###################################################
### code chunk number 5: Lesson_1.Rnw:259-262 (eval = FALSE)
###################################################
## setwd("yourworkingdirectory")
## # This sets the working directory (where R looks for files)
## getwd() # Double check your working directory


###################################################
### code chunk number 6: Lesson_1.Rnw:265-266
###################################################
datdir <- file.path("data") ## path


###################################################
### code chunk number 7: Lesson_1.Rnw:274-279
###################################################
add <- function(x){ 
#put the function arguments in () and the evaluation in {}
  x + 1
}
add(4) 


###################################################
### code chunk number 8: Lesson_1.Rnw:282-288
###################################################
add <- function(x = 5) {
  z <- x + 1
  return(z)
}
add() 
add(6)


###################################################
### code chunk number 9: Lesson_1.Rnw:300-307
###################################################
newfunc <- function(x, y) {
  z <- 2*x + y
  return(c(z,x,y))
} 
a2b <- newfunc(2, 4)
a2b
rm(a, newfunc, a2b)


###################################################
### code chunk number 10: Lesson_1.Rnw:344-345 (eval = FALSE)
###################################################
## install.packages("rasta", repos="http://R-Forge.R-project.org")


###################################################
### code chunk number 11: Lesson_1.Rnw:348-349
###################################################
library(rasta) ## load the rasta library


###################################################
### code chunk number 12: Lesson_1.Rnw:352-354 (eval = FALSE)
###################################################
## ?mysummary
## mysummary


###################################################
### code chunk number 13: Lesson_1.Rnw:370-373
###################################################
f <- system.file(file.path("extdata", "kenpop89to99.csv"), 
                 package ="rasta")
mydat <- read.csv(f)


###################################################
### code chunk number 14: Lesson_1.Rnw:378-381
###################################################
names(mydat)[1:3]
summary(mydat$Y89Pop)[1:3]
head(mydat$Y89Births)[1:2]


###################################################
### code chunk number 15: regression
###################################################
myreg<-lm(Y99Pop ~ Y89Births + Y89Brate, data = mydat) 
myreg[c(1,8)]


###################################################
### code chunk number 16: Lesson_1.Rnw:408-412
###################################################
names(myreg)[1:3]
myregsum <- summary(myreg)
myregsum[["adj.r.squared"]] #extract the adjusted r squared
myregsum$adj.r.squared # does the same thing


###################################################
### code chunk number 17: Lesson_1.Rnw:423-425
###################################################
## Load required packages
library(rasta)


###################################################
### code chunk number 18: Lesson_1.Rnw:431-439
###################################################
require(raster)
if (!file.exists(datdir)) { dir.create(datdir)}
if (!file.exists(file.path(datdir, "PHL_adm2.RData"))) {
  adm <- raster::getData("GADM", country = "PHL", level=2, path = "data/")
} else {
  load(file.path(datdir, "PHL_adm2.RData"))
  adm <- gadm
}


###################################################
### code chunk number 19: Lesson_1.Rnw:443-445 (eval = FALSE)
###################################################
## ?getData
## ?raster::getData


###################################################
### code chunk number 20: Lesson_1.Rnw:451-452 (eval = FALSE)
###################################################
## raster::getData("ISO3")


###################################################
### code chunk number 21: Lesson_1.Rnw:457-460 (eval = FALSE)
###################################################
## adm <- raster::getData("GADM", country = "PHL", 
##                        level = 2, path = datdir)
## plot(adm)


###################################################
### code chunk number 22: phil
###################################################
mar <- adm[adm$NAME_1 == "Marinduque",]
plot(mar, bg = "dodgerblue", axes=T)
plot(mar, lwd = 10, border = "skyblue", add=T)
plot(mar, col = "green4", add = T)
grid()
box()
invisible(text(getSpPPolygonsLabptSlots(mar), 
labels = as.character(mar$NAME_2), cex = 1.1, col = "white", font = 2))
mtext(side = 3, line = 1, "Provincial Map of Marinduque", cex = 2)
mtext(side = 1, "Longitude", line = 2.5, cex=1.1)
mtext(side = 2, "Latitude", line = 2.5, cex=1.1) 
text(122.08, 13.22, "Projection: Geographic\n
Coordinate System: WGS 1984\n
Data Source: GADM.org", adj = c(0, 0), cex = 0.7, col = "grey20")


###################################################
### code chunk number 23: ggplotphil (eval = FALSE)
###################################################
## require(ggmap)
## shp.spdf <- adm[adm$NAME_1=="Marinduque",]
## shp.df <- fortify(shp.spdf)
## shp.centroids.df <- data.frame(long = coordinates(shp.spdf)[,1], 
##                                lat = coordinates(shp.spdf)[,2])
## # Get names and id numbers corresponding to administrative areas
## shp.centroids.df[, "ID_1"] <- shp.spdf@data[,"ID_1"]
## shp.centroids.df[, "NAME_2"] <- shp.spdf@data[,"NAME_2"]
## q <- qmap(location = "Marinduque", zoom = 10, maptype = "satellite")
## q = q +  geom_polygon(aes(x = long, y = lat, group = group), 
##     data = shp.df, 
##     colour = "white", fill = "black", alpha = .4, size = .3) 
## 
## q = q + geom_text(data = shp.centroids.df, 
##     aes(label = NAME_2, x = long, y = lat, group = NAME_2), 
##                   size = 3, colour= "white")
## print(q)


