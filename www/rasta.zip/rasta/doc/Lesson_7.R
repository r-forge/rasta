### R code from vignette source 'Lesson_7.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: packages
###################################################
# load the necessary packages
library(rasta)
library(raster)
library(rgdal)
library(sp)
library(ggplot2)
library(rasterVis)


###################################################
### code chunk number 2: loadTura
###################################################
data(tura)

# inspect the data
class(tura) # the object's class
projection(tura) # the projection
res(tura) # the spatial resolution (x, y)
extent(tura) # the extent of the raster brick


###################################################
### code chunk number 3: namesTura
###################################################
# display the names of all layers in the tura RasterBrick
names(tura)


###################################################
### code chunk number 4: parseSceneInfo
###################################################
# display the 1st 3 characters of the layer names
sensor <- substr(names(tura), 1, 3)
print(sensor)

# display the path and row as numeric vectors in the form (path,row)
path <- as.numeric(substr(names(tura), 4, 6))
row <- as.numeric(substr(names(tura), 7, 9))
print(paste(path, row, sep = ","))

# display the date
dates <- substr(names(tura), 10, 16)
print(dates)

# format the date in the format yyyy-mm-dd
as.Date(dates, format="%Y%j")


###################################################
### code chunk number 5: scenesAvailable
###################################################
# ?getSceneinfo
sceneinfo <- getSceneinfo(names(tura))
print(sceneinfo)
# add a 'year' column to the sceneinfo dataframe and plot #scenes/year
sceneinfo$year <- factor(substr(sceneinfo$date, 1, 4), levels = c(1984:2013))

ggplot(data = sceneinfo, aes(x = year, fill = sensor)) + 
  geom_bar() + 
  labs(y = "number of scenes") + 
  scale_y_continuous(limits=c(0, 20)) +
  theme_bw() +
  theme(axis.text.x=element_text(angle = 45),
        legend.position=c(0.9, 0.85))


###################################################
### code chunk number 6: plotTura (eval = FALSE)
###################################################
## plot(tura, c(1:9))
## # alternatively, you can use [[]] notation to specify layers
## plot(tura[[1:9]])
## # use the information from sceneinfo data.frame to clean up the titles
## plot(tura[[1:9]], main = sceneinfo$date[c(1:9)])


###################################################
### code chunk number 7: plotTura2 (eval = FALSE)
###################################################
## # we need to define the breaks to harmonize the scales (to make the plots comparable)
## bks <- seq(0, 10000, by = 2000) # (arbitrarily) define the breaks
## # we also need to redefine the colour palette to match the breaks
## cols <- rev(terrain.colors(length(bks))) # col = rev(terrain.colors(255)) is the default colour palette parameter set in raster plots, but there are many more options available!
## # (opt: check out the RColorBrewer package for other colour palettes)
## # plot again with the new parameters
## plot(tura[[1:9]], main = sceneinfo$date[1:9], breaks = bks, col = cols)


###################################################
### code chunk number 8: levelplotTura
###################################################
library(rasterVis)
levelplot(tura[[1:6]])
# NOTE:
# for rasterVis plots we must use the [[]] notation for extracting layers

# providing titles to the layers is done using 
# the 'names.attr' argument in place of 'main'
levelplot(tura[[1:6]], names.attr = sceneinfo$date[1:6])
# define a more logical colour scale
library(RColorBrewer)
# this package has a convenient tool for defining colour palettes
# ?brewer.pal
display.brewer.all()
cols <- brewer.pal(11, 'PiYG')
# to change the colour scale in levelplot(), 
# we first have to define a rasterTheme object
# see ?rasterTheme() for more info
rtheme <- rasterTheme(region = cols)


###################################################
### code chunk number 9: levelplotTura2
###################################################
levelplot(tura[[1:6]], names.attr = sceneinfo$date[1:6], par.settings = rtheme)


###################################################
### code chunk number 10: otherPlots
###################################################
# histograms of the first 6 layers
histogram(tura[[1:6]])
# box and whisker plot of the first 9 layers
bwplot(tura[[1:9]])


###################################################
### code chunk number 11: DataLossScene
###################################################
# try for one layer first
y <- freq(tura[[1]]) # this is a matrix
y <- as.data.frame(y)
print(y)
# how many NA's are there in this table?
y$count[is.na(y$value)]
# alternatively, using the with() function:
with(y, count[is.na(value)])
# as a %
with(y, count[is.na(value)]) / ncell(tura[[1]]) * 100

# We can compute this more efficiently
# by using the 'value' argument in freq()
y <- freq(tura[[1]], value=NA)
print(y)
# apply over all layers of the rasterBrick
y <- freq(tura, value=NA)
print(y)
# convert this to % pixels per scene
y <- freq(tura, value=NA) / ncell(tura) * 100
# add this vector as a column in the sceneinfo data.frame
#(rounded to 2 decimal places)
sceneinfo$nodata <- round(y, 2)


###################################################
### code chunk number 12: DataLossScenePlot
###################################################
# plot these values
ggplot(data = sceneinfo, aes(x = date, y = nodata, shape = sensor)) +
  geom_point(size = 2) +
  labs(y = "% nodata") +
  theme_bw()


###################################################
### code chunk number 13: dropLayers
###################################################
# which layers have 100% data loss?
which(sceneinfo$nodata == 100)
# supply these indices to the dropLayer() command to get rid of these layers
tura <- dropLayer(tura, which(sceneinfo$nodata == 100))
# redefine our sceneinfo data.frame so to correspond with rasterBrick
sceneinfo <- sceneinfo[which(sceneinfo$nodata != 100), ]
# optional: remake the previous ggplots with this new dataframe


###################################################
### code chunk number 14: calcNA
###################################################
# calc() will apply a function over each pixel
# in this case, each pixel represents a time series of NDVI values
# e.g. extract all values of the 53rd pixel in the raster grid
y <- as.numeric(tura[53])
print(y) # integer vector from time series values
# how many of these values have been masked (NA)?
length(y[is.na(y)])
# as a %
length(y[is.na(y)]) / length(y) * 100
# now wrap this in a calc() to apply over all pixels of the RasterBrick
nodata <- calc(tura, fun = function(x) length(x[is.na(x)]) / length(x) * 100)
# sometimes it's more readable to define the function first
percNA <- function(x){
  y <- length(x[is.na(x)]) / length(x) * 100
  return(y)
}
nodata <- calc(tura, fun=percNA)
# plot the nodata raster
plot(nodata)


###################################################
### code chunk number 15: clickTS (eval = FALSE)
###################################################
## plot(tura, 101)
## x <- click(tura, n=1)
## # returns a matrix with n=1 rows
## class(x)
## # convert it to an integer vector
## x <- x[1,]
## # or....
## x <- as.numeric(x)
## # note that the 2nd method removes the names of the vector!
## # plot the vector
## plot(x)


###################################################
### code chunk number 16: LULC_TS
###################################################
# several pixel coordinate pairs expressed as separate 1-row matrices
forest <- matrix(data=c(819935, 832004), nrow=1, 
                 dimnames=list(NULL, c('x', 'y')))
cropland <- matrix(data=c(819440, 829346), nrow=1, 
                   dimnames=list(NULL, c('x', 'y')))
wetland <- matrix(data = c(822432, 832076), nrow=1, 
                  dimnames=list(NULL, c('x', 'y')))

# recall that we can extract pixel data if we know the cell #
# we can easily convert from xy matrix to cell number with cellFromXY()
forestCell <- cellFromXY(tura, forest)
print(forestCell)
croplandCell <- cellFromXY(tura, cropland)
wetlandCell <- cellFromXY(tura, wetland)
# return a 1-row matrix with all time series values from this raster cell
tura[forestCell]


###################################################
### code chunk number 17: ts-df
###################################################
# prepare the data.frame
# combine data returned earlier from getSceneinfo() with time series values
ts <- data.frame(sensor = getSceneinfo(names(tura))$sensor,
                 date = getSceneinfo(names(tura))$date,
                 forest = t(tura[forestCell]),
                 cropland = t(tura[croplandCell]),
                 wetland = t(tura[wetlandCell])
                 )
print(ts)


###################################################
### code chunk number 18: tsplots (eval = FALSE)
###################################################
## # simple plot of forest time series with NDVI scaled back to original values
## # recall that the time series value is NDVI*10000 (see Lesson 6)
## plot(ts$date, ts$forest/10000, xlab="date", ylab="NDVI")
## # same thing, but using with()
## with(ts, plot(date, forest/10000, xlab="date", ylab="NDVI"))


###################################################
### code chunk number 19: removeTM
###################################################
# remove all data from the TM sensor and plot again
ts <- ts[which(ts$sensor!="TM"), ]
# alternatively, using subset()
ts <- subset(ts, sensor!="TM")
# plot the new time series
with(ts, plot(date, forest, xlab="date", ylab="NDVI"))


###################################################
### code chunk number 20: reshape
###################################################
library(reshape)
# convert dates to characters, otherwise melt() returns an error
ts$date <- as.character(ts$date)
# 'melt' the data.frame
tsmelt <- melt(ts)
# inspect the new data.frame
head(tsmelt)
# change the 'variable' column heading to 'class'
names(tsmelt)[3] <- "class"
# convert tsplot$date back to Date class to enable formatting of the plot
tsmelt$date <- as.Date(tsmelt$date)
# inspect the data.frame
tsmelt


###################################################
### code chunk number 21: reshapePlot
###################################################
ggplot(data = tsmelt, aes(x = date, y = value / 10000)) +
  geom_point() +
  scale_x_date() +
  labs(y = "NDVI") +
  facet_wrap(~ class, nrow = 3) +
  theme_bw()


