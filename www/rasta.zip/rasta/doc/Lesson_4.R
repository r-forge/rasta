### R code from vignette source 'Lesson_4.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: SimplePoints
###################################################
# load sp package
library(sp)
library(rgdal)

# coordinates of two points identiefied in Google Earth, for example
pnt1_xy <- cbind(5.6660, 51.9872)   # enter your own coordinates
pnt2_xy <- cbind(5.6643, 51.9668)   # enter your own coordinates
# combine coordinates in single matrix
coords <- rbind(pnt1_xy, pnt2_xy)

# make spatial points object
prj_string_WGS <- CRS("+proj=longlat +datum=WGS84")
mypoints <- SpatialPoints(coords, proj4string=prj_string_WGS)


###################################################
### code chunk number 2: Lesson_4.Rnw:100-103 (eval = FALSE)
###################################################
## # inspect object
## class(mypoints)
## str(mypoints)


###################################################
### code chunk number 3: PointsDataFrame
###################################################
# create and display some attribute data and store in a data frame
mydata <- data.frame(cbind(id = c(1,2), 
                Name = c("my description 1", 
                         "my description 2")))

# make spatial points data frame
mypointsdf <- SpatialPointsDataFrame(
  coords, data = mydata, 
  proj4string=prj_string_WGS)


###################################################
### code chunk number 4: Inspect (eval = FALSE)
###################################################
## class(mypointsdf) # inspect and plot object
## names(mypointsdf)
## str(mypointsdf)
## spplot(mypointsdf, zcol="Name", col.regions = c("red", "blue"), 
##        xlim = bbox(mypointsdf)[1, ]+c(-0.01,0.01), 
##        ylim = bbox(mypointsdf)[2, ]+c(-0.01,0.01),
##        scales= list(draw = TRUE))


###################################################
### code chunk number 5: Lines
###################################################
# consult help on SpatialLines class
simple_line <- Line(coords)
lines_obj <- Lines(list(simple_line), "1")
spatlines <- SpatialLines(list(lines_obj), proj4string=prj_string_WGS)
line_data <- data.frame(Name = "straight line", row.names="1")
mylinesdf <- SpatialLinesDataFrame(spatlines, line_data)


###################################################
### code chunk number 6: Lesson_4.Rnw:143-149 (eval = FALSE)
###################################################
## class(mylinesdf)
## str(mylinesdf)
## spplot(mylinesdf, col.regions = "blue", 
##        xlim = bbox(mypointsdf)[1, ]+c(-0.01,0.01), 
##        ylim = bbox(mypointsdf)[2, ]+c(-0.01,0.01),
##        scales= list(draw = TRUE))


###################################################
### code chunk number 7: writeOGR (eval = FALSE)
###################################################
## library(rgdal)
## # write to kml ; below we assume a subdirectory data within the current 
## # working directory.
## 
## writeOGR(mypointsdf, file.path("data","mypointsGE.kml"), 
##          "mypointsGE", driver="KML", overwrite_layer=TRUE)
## writeOGR(mylinesdf, file.path("data","mylinesGE.kml"), 
##          "mylinesGE", driver="KML", overwrite_layer=TRUE)


###################################################
### code chunk number 8: readOGR (eval = FALSE)
###################################################
## myroute <- readOGR(file.path("data","route.kml"), "route.kml")


###################################################
### code chunk number 9: readOGR
###################################################
if (!file.exists(file.path("data","route.rda"))) {
  myroute <- readOGR(file.path("data","route.kml"), "route.kml")
  save(myroute, file = file.path("data","route.rda"), compress="xz")
} else {
  load(file.path("data","route.rda"))
}


###################################################
### code chunk number 10: readOGR
###################################################
# put both in single data frame
myroute@proj4string <- prj_string_WGS
names(myroute)
myroute$Description <- NULL
mylinesdf <- rbind(mylinesdf, myroute)


###################################################
### code chunk number 11: Transformation
###################################################
# define CRS object for RD projection
prj_string_RD <- CRS("+proj=sterea +lat_0=52.15616055555555 +lon_0=5.38763888888889 
+k=0.9999079 +x_0=155000 +y_0=463000 +ellps=bessel +towgs84=565.2369,50.0087,465.658,
-0.406857330322398,0.350732676542563,-1.8703473836068,4.0812 +units=m +no_defs")

# perform the coordinate transformation from WGS84 to RD
mylinesRD <- spTransform(mylinesdf, prj_string_RD)


###################################################
### code chunk number 12: Lesson_4.Rnw:216-219
###################################################
# use rgeos for computing the length of lines 
library(rgeos)
mylinesdf$length <- gLength(mylinesRD, byid=T)


###################################################
### code chunk number 13: Polygons
###################################################
# make circles around points, with radius equal to distance between points 
mypointsRD <- spTransform(mypointsdf, prj_string_RD)
pnt1_rd <- coordinates(mypointsRD)[1,]
pnt2_rd <- coordinates(mypointsRD)[2,]
# define a series of angles
ang <- pi*0:200/100
circle1x <- pnt1_rd[1] + cos(ang) * mylinesdf$length[1]
circle1y <- pnt1_rd[2] + sin(ang) * mylinesdf$length[1]
circle2x <- pnt2_rd[1] + cos(ang) * mylinesdf$length[1]
circle2y <- pnt2_rd[2] + sin(ang) * mylinesdf$length[1] 

# Iterate through some steps to create SpatialPolygonsDataFrame object
circle1 <- Polygons(list(Polygon(cbind(circle1x, circle1y))),"1")
circle2 <- Polygons(list(Polygon(cbind(circle2x, circle2y))),"2")
spcircles <- SpatialPolygons(list(circle1, circle2), proj4string=prj_string_RD)
circledat <- data.frame(mypointsRD@data, row.names=c("1", "2"))
circlesdf <- SpatialPolygonsDataFrame(spcircles, circledat)


###################################################
### code chunk number 14: Buffering
###################################################
buffpoint <- gBuffer(mypointsRD[1,], width=mylinesdf$length[1], quadsegs=25)
mydiff <- gDifference(circlesdf[1,], buffpoint)
gArea(mydiff)
myintersection <- gIntersection(circlesdf[1,], buffpoint)
gArea(myintersection)
print(paste("The difference in area =", round(100 * gArea(mydiff) / 
                                             gArea(myintersection),3), "%"))


###################################################
### code chunk number 15: basicGeometry
###################################################
spplot(circlesdf, zcol="Name", col.regions=c("gray60", "gray40"), 
       sp.layout=list(list("sp.points", mypointsRD, col="red", pch=19, cex=1.5), 
                      list("sp.lines", mylinesRD, lwd=1.5)))


###################################################
### code chunk number 16: Lesson_4.Rnw:285-292
###################################################
if (!file.exists("data/kroonven.rda")) {
  download.file("http://rasta.r-forge.r-project.org/kroonven.csv", "kroonven.csv")
  borne_data = read.table("kroonven.csv", sep = ",", header = TRUE)
  save(borne_data, file = "data/kroonven.rda", compress="xz")
} else {
  load("data/kroonven.rda")
}


###################################################
### code chunk number 17: Lesson_4.Rnw:295-298 (eval = FALSE)
###################################################
## # download and read data
## download.file("http://rasta.r-forge.r-project.org/kroonven.csv", "kroonven.csv")
## borne_data = read.table("kroonven.csv", sep = ",", header = TRUE)


###################################################
### code chunk number 18: yieldPoints
###################################################
names(borne_data)
# make spatial
coordinates(borne_data) <- c("lon.degr.","lat.degr.")
borne_data@proj4string <- prj_string_WGS
# transform to planar coordinate system
all_rd <- spTransform(borne_data, prj_string_RD)
dimnames(all_rd@coords)[[2]] <- c("x", "y")
# plot the point data
spplot(all_rd, zcol="yield.ton.ha.", colorkey=T, zlim=c(0,100),
       col.regions=c(bpy.colors(25), rep("yellow", 75)), pch=19, 
       cex=0.25, main="Recorded yields ton/ha")


###################################################
### code chunk number 19: Lesson_4.Rnw:324-328
###################################################
# add datetime attribute using POSIX class
all_rd$datetime <- as.POSIXct(paste(paste(all_rd$year, all_rd$month, all_rd$day, 
                              sep="-"), paste(all_rd$hr, all_rd$min, all_rd$sec, 
                              sep=":")), tz="Europe/Andorra")


###################################################
### code chunk number 20: Lesson_4.Rnw:336-341
###################################################
# coerce spatial data frame to data frame
all_rd <- as.data.frame(all_rd)
# make sure points are temporally ordered
all_rd <- all_rd[order(all_rd$datetime),]
library(rasta)


###################################################
### code chunk number 21: Lesson_4.Rnw:344-350
###################################################
if (!file.exists("data/sp_lines_df.rda")) {
  sp_lines_df <- CreateHarvestTracks(all_rd, prj_string_RD)
  save(sp_lines_df, file = "data/sp_lines_df.rda", compress = "xz")
} else {
  load("data/sp_lines_df.rda")
}


###################################################
### code chunk number 22: Lesson_4.Rnw:353-355 (eval = FALSE)
###################################################
## # call function from rasta to create lines; will take a minute or so
## sp_lines_df <- CreateHarvestTracks(all_rd, prj_string_RD)


###################################################
### code chunk number 23: harvestTracks
###################################################
# inspect results
names(sp_lines_df)
spplot(sp_lines_df, zcol="ID", lwd=1.5, col.regions = 
         bpy.colors(nlevels(sp_lines_df$ID)))


###################################################
### code chunk number 24: Lesson_4.Rnw:377-405
###################################################
# Buffer lines to make swaths
sp_polys <- gBuffer(sp_lines_df,byid=T, width=0.5*sp_lines_df$width, 
                    capStyle="FLAT")
# fill small holes by swelling and shrinking
sp_polys <- gBuffer(sp_polys, byid=T,id=rownames(sp_polys), width = 2.0)
sp_polys <- gBuffer(sp_polys, byid=T,id=rownames(sp_polys), width = -2.0)

sp_polys_df <- SpatialPolygonsDataFrame(sp_polys, sp_lines_df@data)

# Remove line segments that are within already harvested swaths using 
# gDifference
tmp_lines <- sp_lines_df@lines # just a list with geometries
for (i in 2:length(sp_lines_df)){
  tmline <- sp_lines_df[i,]$datim
  for (j in 1:(i-1)){
    tmpoly <- sp_polys_df[j,]$datim
    if (difftime(tmline, tmpoly, units = "secs") > 0){
      tmp_line <- SpatialLines(tmp_lines[i], prj_string_RD)
      if (gIntersects(tmp_line, sp_polys_df[j,])){
        # compute difference
        tmp_lines[[i]] <- gDifference(tmp_line, sp_polys_df[j,])@lines[[1]]
        tmp_lines[[i]]@ID <- sp_lines_df[i,]@lines[[1]]@ID
      }
    }
  }
}
tmp_lines <- SpatialLines(tmp_lines, prj_string_RD)
cln_lines_df <- SpatialLinesDataFrame(tmp_lines, sp_lines_df@data)


###################################################
### code chunk number 25: Answers (eval = FALSE)
###################################################
## # Q1 -- Buffer lines to make swaths
## sp_polys2 <- gBuffer(cln_lines_df,byid=T,id=as.character(cln_lines_df$ID), 
##                     width=0.5*cln_lines_df$width, capStyle="FLAT")
## # Q2 fill small holes by swelling and shrinking
## sp_polys2 <- gBuffer(sp_polys2, byid=T,id=rownames(sp_polys2), width = 2.0)
## sp_polys2 <- gBuffer(sp_polys2, byid=T,id=rownames(sp_polys2), width = -2.0)
## 
## sp_polys_df2 <- SpatialPolygonsDataFrame(sp_polys2, cln_lines_df@data)
## 
## # Q3 compute area and ton/ha
## sp_polys_df2$area <- gArea(sp_polys_df2, byid=T)
## sp_polys_df2$ton_ha <- 10000 * sp_polys_df2$loads / sp_polys_df2$area
## names(sp_polys_df2)
## # Q4 plot
## spplot(sp_polys_df2["ton_ha"], col="transparent", col.regions=bpy.colors(100), 
##        main="Potato yield (ton/ha)")
## 
## # Q 5 Google Earth output
## # (1) Export to Google Earth using writeOGR
## sp_polys_wgs <- spTransform(sp_polys_df2, CRS("+proj=longlat +datum=WGS84"))
## writeOGR(sp_polys_WGS, "data/testkml.kml", "testkml", driver="KML", overwrite_layer=T)
## 
## # (2) Idem, using package "plotKML" Tomislav Hengl
## library(plotKML)
## kml(sp_polys_wgs, colour = ton_ha, colour_scale=bpy.colors(), outline=F)
## 
## # (3) Add a legend as a screen overlay
## kml_legend.bar(sp_polys_wgs$ton_ha, legend.file="leg.png", pointsize = 10, 
##                legend.pal=bpy.colors())
## 
## kml_open("sp_polys_wgs2.kml")
## kml_layer(sp_polys_wgs, colour = ton_ha, colour_scale=bpy.colors(), outline=F)
## kml_screen("leg.png", position = "UL")
## kml_close("sp_polys_wgs2.kml")
## 
## # Extra: Animation data acquisition with time
## borne_data = read.table(in_file, sep = ",", header = T)
## # make spatial
## coordinates(borne_data) <- c("lon.degr.","lat.degr.")
## TimeStamp <- paste(paste(borne_data$year, sprintf("%02d", borne_data$month), 
##                 sprintf("%02d", borne_data$day), sep="-"),
##                 paste(sprintf("%02d", borne_data$hr),  sprintf("%02d", 
##                 borne_data$min), sprintf("%02d", borne_data$sec), sep=":"),sep="T")
## borne_data@proj4string <- CRS("+proj=longlat +datum=WGS84")
## max_t <- tail(TimeStamp,1)
## kml(borne_data, colour = loadnr, colour_scale=bpy.colors(), labels = "", 
##     TimeSpan.begin = TimeStamp, TimeSpan.end=max_t)
## 


