### R code from vignette source 'Lesson_8.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: preliminaries
###################################################
options(width = 80, prompt = ">", continue = "+ ")


###################################################
### code chunk number 2: Lesson_8.Rnw:71-73 (eval = FALSE)
###################################################
## library(devtools)
## install_bitbucket(repo='vcf', username='dutri001')


