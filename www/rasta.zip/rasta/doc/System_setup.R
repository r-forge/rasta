### R code from vignette source 'System_setup.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: System_setup.Rnw:147-149 (eval = FALSE)
###################################################
## install.packages("rasta", repos="http://R-Forge.R-project.org", 
##                  type = "source")


