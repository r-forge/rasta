### R code from vignette source 'Lesson_6.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: Lesson_6.Rnw:52-59
###################################################
# load the necessary packages
library(rasta)
library(raster)
library(rgdal)
library(sp)
library(ggplot2)
library(rasterVis)


###################################################
### code chunk number 2: Lesson_6.Rnw:85-102
###################################################
# load in the data
data(GewataB2)
data(GewataB3)
data(GewataB4)
# check out the attributes
GewataB2
# some basic statistics using cellStats()
cellStats(GewataB2, stat=max)
# ...is equivalent to:
maxValue(GewataB2)
# what is the maximum value of all three bands?
max(c(maxValue(GewataB2), maxValue(GewataB3), maxValue(GewataB4)))

# plot the histograms of all bands
hist(GewataB2)
hist(GewataB3)
hist(GewataB4)


###################################################
### code chunk number 3: Lesson_6.Rnw:107-111
###################################################
library(rasterVis)
gewata <- brick(GewataB2, GewataB3, GewataB4)
# view all histograms together with rasterVis
histogram(gewata)


###################################################
### code chunk number 4: Lesson_6.Rnw:116-117
###################################################
splom(gewata)


###################################################
### code chunk number 5: Lesson_6.Rnw:122-123
###################################################
splom(gewata)


###################################################
### code chunk number 6: Lesson_6.Rnw:144-145
###################################################
ndvi <- (GewataB4 - GewataB3) / (GewataB4 + GewataB3)


###################################################
### code chunk number 7: Lesson_6.Rnw:150-151 (eval = FALSE)
###################################################
## ndvi <- overlay(GewataB4, GewataB3, fun=function(x,y){(x-y)/(x+y)})


###################################################
### code chunk number 8: Lesson_6.Rnw:158-167 (eval = FALSE)
###################################################
## # first, plot the raster
## plot(ndvi)
## # call drawExtent() to activate interactive mode
## # and assign the result to an extent object e
## e <- drawExtent()
## # now click 2 points on the plot window
## # these represent the top-right and bottom-left corner of your extent
## # now plot ndvi again, but only the extent you defined interactively
## plot(ndvi, ext=e)


###################################################
### code chunk number 9: Lesson_6.Rnw:183-187
###################################################
# load the data
data(vcfGewata)
plot(vcfGewata)
histogram(vcfGewata) # or 'hist(vcfGewata)'


###################################################
### code chunk number 10: Lesson_6.Rnw:192-195
###################################################
vcfGewata[vcfGewata > 100] <- NA
plot(vcfGewata)
histogram(vcfGewata)


###################################################
### code chunk number 11: Lesson_6.Rnw:200-209
###################################################
ndvi <- calc(ndvi, fun = function(x) floor(x*10000))
# change the data type
# see ?dataType for more info
dataType(ndvi) <- "INT2U"
# name this layer to make plots interpretable
names(ndvi) <- "NDVI"
# make the covariate rasterBrick
covs <- addLayer(gewata, ndvi, vcfGewata)
plot(covs)


###################################################
### code chunk number 12: Lesson_6.Rnw:214-221
###################################################
# load the training polygons
data(trainingPoly)
# inspect the data
trainingPoly@data
# superimpose training polygons onto ndvi plot
plot(ndvi)
plot(trainingPoly, add = TRUE)


###################################################
### code chunk number 13: Lesson_6.Rnw:226-236
###################################################
# define a reclassification function
reclass <- function(x){
  y <- ifelse(x == "forest", 1,
              ifelse(x == "cropland", 2, 3)
              )
  return(y)
}
# apply this over the trainingPoly data slot
trainingPoly@data$Code <- sapply(trainingPoly@data$Class, 
                                 FUN = function(x) reclass(x))


###################################################
### code chunk number 14: Lesson_6.Rnw:241-244
###################################################
classes <- rasterize(trainingPoly, ndvi, field = 'Code')
dataType(classes) <- "INT1U"
plot(classes, col = c("dark green", "orange", "light blue"))


###################################################
### code chunk number 15: Lesson_6.Rnw:251-257
###################################################
covmasked <- mask(covs, classes)
plot(covmasked)
# add the classes layer to this new brick
names(classes) <- "class"
trainingbrick <- addLayer(covmasked, classes)
plot(trainingbrick)


###################################################
### code chunk number 16: Lesson_6.Rnw:262-268
###################################################
# extract all values into a matrix
valuetable <- getValues(trainingbrick)
# convert to a data.frame and inspect the first and last rows
valuetable <- as.data.frame(valuetable)
head(valuetable)
tail(valuetable)


###################################################
### code chunk number 17: Lesson_6.Rnw:273-279
###################################################
# keep only rows where valuetable$classes has a value
valuetable <- valuetable[!is.na(valuetable$class),]
head(valuetable)
tail(valuetable)
# convert values in the class column to factors
valuetable$class <- factor(valuetable$class, levels = c(1:3))


###################################################
### code chunk number 18: Lesson_6.Rnw:284-308
###################################################
# 1. NDVI
ggplot(data = valuetable, aes(x = NDVI)) + 
  geom_histogram() + 
  facet_wrap(~ class) +
  theme_bw()

# 2. VCF
ggplot(data = valuetable, aes(x = vcf2000Gewata)) +
  geom_histogram() +
  labs(x = "% Tree Cover") +
  facet_wrap(~ class) +
  theme_bw()

# 3. Bands 3 and 4
ggplot(data = valuetable, aes(x = gewataB3, y = gewataB4)) +
  stat_bin2d() +
  facet_wrap(~ class) +
  theme_bw()

# 4. Bands 2 and 3
ggplot(data = valuetable, aes(x = gewataB2, y = gewataB3)) +
  stat_bin2d() +
  facet_wrap(~ class) +
  theme_bw()


###################################################
### code chunk number 19: Lesson_6.Rnw:315-320
###################################################
# NA values are not permitted in the covariates/predictor columns
# which rows have NAs in them?
delRows <- which(apply(valuetable, 1, FUN = function(x) NA %in% x))
# remove these rows from valuetable
valuetable <- valuetable[-delRows,]


###################################################
### code chunk number 20: Lesson_6.Rnw:322-327 (eval = FALSE)
###################################################
## # construct a random forest model
## # caution: this step takes fairly long!
## library(randomForest)
## modelRF <- randomForest(x = valuetable[,c(1:5)], y = valuetable$class,
##                         importance = TRUE)


###################################################
### code chunk number 21: Lesson_6.Rnw:329-337
###################################################
library(randomForest)
if(!file.exists("data/modelRF.rda")){
  modelRF <- randomForest(x = valuetable[,c(1:5)], y = valuetable$class,
                        importance = TRUE)
  save(modelRF, file='data/www/modelRF.rda', compress="bzip2", ascii=FALSE)
} else {
  load('data/modelRF.rda')
}


###################################################
### code chunk number 22: Lesson_6.Rnw:344-350
###################################################
# inspect the structure and element names of the resulting model
class(modelRF)
str(modelRF)
names(modelRF)
# inspect the confusion matrix of the OOB error assessment
modelRF$confusion


###################################################
### code chunk number 23: Lesson_6.Rnw:355-356
###################################################
varImpPlot(modelRF)


###################################################
### code chunk number 24: Lesson_6.Rnw:365-373
###################################################
# check layer and column names
names(covs)
names(valuetable)
# predict land cover using the RF model
predLC <- predict(covs, model=modelRF, na.rm=TRUE)
# plot the results
# recall: 1 = forest, 2 = cropland, 3 = wetland
plot(predLC, col=c("dark green", "orange", "light blue"))


###################################################
### code chunk number 25: Lesson_6.Rnw:377-378
###################################################
plot(predLC, col=c("dark green", "orange", "light blue"))


###################################################
### code chunk number 26: Lesson_6.Rnw:392-394
###################################################
valuetable <- getValues(covs)
head(valuetable)


###################################################
### code chunk number 27: Lesson_6.Rnw:399-400 (eval = FALSE)
###################################################
## km <- kmeans(na.omit(valuetable), centers = 3, iter.max = 100, nstart = 10)


###################################################
### code chunk number 28: Lesson_6.Rnw:402-408
###################################################
if(!file.exists('data/km.rda')){
  km <- kmeans(na.omit(valuetable), centers = 3, iter.max = 100, nstart = 10)
  save(km, file='data/km.rda', compres='bzip2', ascii=FALSE)
} else {
  load('data/km.rda')
}


###################################################
### code chunk number 29: Lesson_6.Rnw:410-413
###################################################
# km contains the clusters (classes) assigned to the cells
head(km$cluster)
unique(km$cluster) # displays unique values


###################################################
### code chunk number 30: Lesson_6.Rnw:418-429
###################################################
# create a blank raster with NA values
rNA <- setValues(raster(covs), NA)
# loop through layers of covs
# assign a 1 wherever an NA is enountered
for(i in 1:nlayers(covs)){
  rNA[is.na(covs[[i]])] <- 1
}
# convert rNA to an integer vector
rNA <- getValues(rNA)
# substitue the NA's for 0's
rNA[is.na(rNA)] <- 0


###################################################
### code chunk number 31: Lesson_6.Rnw:436-442
###################################################
# convert valuetable to a data.frame
valuetable <- as.data.frame(valuetable)
# assign the cluster values (where rNA != 1)
valuetable$class[rNA==0] <- km$cluster
# assign NA to this column elsewhere
valuetable$class[rNA==1] <- NA


###################################################
### code chunk number 32: Lesson_6.Rnw:447-452
###################################################
# create a blank raster
classes <- raster(covs)
# assign values from the 'class' column of valuetable
classes <- setValues(classes, valuetable$class)
plot(classes, col=c("dark green", "orange", "light blue"))


###################################################
### code chunk number 33: Lesson_6.Rnw:457-458
###################################################
plot(classes, col=c("dark green", "orange", "light blue"))


###################################################
### code chunk number 34: Lesson_6.Rnw:471-478
###################################################
# Make an empty raster based on the LC raster attributes
formask <- raster(predLC)
# assign NA to all cells
formask <- setValues(formask, value = NA)
# assign 1 to all cells corresponding to the forest class
formask[predLC==1] <- 1
plot(formask, col = "dark green", legend = FALSE)


###################################################
### code chunk number 35: Lesson_6.Rnw:487-495
###################################################
# make an empty raster
sievemask <- setValues(raster(formask), NA)
# assign a value of 1 for all forest pixels
sievemask[!is.na(formask)] <- 1
# sum of all neighbourhood pixels
sievemask <- focal(sievemask, w=3, fun=sum, na.rm=TRUE)
sievemask
histogram(sievemask)


###################################################
### code chunk number 36: Lesson_6.Rnw:500-511
###################################################
# copy the original forest mask
formaskSieve <- formask
# assign NA to pixels where the sievemask == 1/9
formaskSieve[sievemask==1/9] <- NA
# zoom in to a small extent to check the results
# Note: you can define your own by using e <- drawExtent()
e <- extent(c(811744.8, 812764.3, 849997.8, 850920.3))
par(mfrow=c(1, 2)) # allow 2 plots side-by-side
plot(formask, ext=e, col="dark green", legend=FALSE)
plot(formaskSieve, ext=e, col="dark green", legend=FALSE)
par(mfrow=c(1, 1)) # reset plotting window


###################################################
### code chunk number 37: Lesson_6.Rnw:516-520
###################################################
par(mfrow=c(1, 2)) # allow 2 plots side-by-side
plot(formask, ext=e, col="dark green", legend=FALSE)
plot(formaskSieve, ext=e, col="dark green", legend=FALSE)
par(mfrow=c(1, 1)) # reset plotting window


###################################################
### code chunk number 38: Lesson_6.Rnw:529-542
###################################################
# define a weights matrix
w <- rbind(c(0, 1, 0),
           c(1, 1, 1),
           c(0, 1, 0))
print(w)
# alternatively:
w <- matrix(c(0, 1, 0, 1, 1, 1, 0, 1, 0), nrow = 3)

# prepare the sievemask (as above)
sievemask <- setValues(raster(formask), NA)
sievemask[!is.na(formask)] <- 1
# sum of all neighbouring pixels, except for diagonals
sievemask <- focal(sievemask, w = w, fun = sum, na.rm = TRUE)


###################################################
### code chunk number 39: Lesson_6.Rnw:552-561
###################################################
# copy the original forest mask
formaskSieve <- formask
# assign NA to pixels where the sievemask == 1/9
formaskSieve[sievemask == 1] <- NA
e <- extent(c(811744.8, 812764.3, 849997.8, 850920.3))
par(mfrow = c(1, 2))
plot(formask, ext = e, col = "dark green", legend = FALSE)
plot(formaskSieve, ext = e, col = "dark green", legend = FALSE)
par(mfrow = c(1, 1))


###################################################
### code chunk number 40: Lesson_6.Rnw:576-580
###################################################
data(lulcGewata)
# check out the distribution of the values
freq(lulcGewata)
hist(lulcGewata)


###################################################
### code chunk number 41: Lesson_6.Rnw:585-587
###################################################
data(LUTGewata)
LUTGewata


###################################################
### code chunk number 42: Lesson_6.Rnw:592-593
###################################################
lulc <- as.factor(lulcGewata)


###################################################
### code chunk number 43: Lesson_6.Rnw:598-601
###################################################
# assign a raster attribute table (RAT)
levels(lulc) <- LUTGewata
lulc


###################################################
### code chunk number 44: Lesson_6.Rnw:606-611
###################################################
classes <- layerize(lulc)
plot(classes)
# layer names follow the order of classes in the LUT
names(classes) <- LUTGewata$Class
plot(classes)


###################################################
### code chunk number 45: Lesson_6.Rnw:616-624
###################################################
forest <- raster(classes, 5)
# is equivalent to:
forest <- classes[[5]]
# or (since the layers are named):
forest <- classes$forest
# replace 0's (non-forest) with NA's
forest[forest==0] <- NA
plot(forest, col="dark green", legend=FALSE)


###################################################
### code chunk number 46: Lesson_6.Rnw:632-688 (eval = FALSE)
###################################################
## # load in the training dataset and LUT
## 
## 
## # separate classes into layers and name the layers
## 
## 
## # extract individual layers
## cropland <- classes$cropland
## # repeat for other classes...
## 
## 
## # replace 0's with NA's in each layer so they don't get sampled
## cropland[cropland==0] <- NA
## # repeat for other classes...
## 
## 
## # select random pixels for each class
## # NOTE: output as a raster or sp object for overlay purposes!
## croplandSamp <- sampleRandom(x=cropland, size=200, asRaster=TRUE)
## # check: there should be 200 pixels with value=1, the rest with value=NA
## 
## 
## # do the same for the other 5 classes
## # you should have a total of 6 'Samp' rasters
## # collect all samples into one raster layer
## classesSamp <- raster(classes) # empty raster
## classesSamp[!is.na(croplandSamp)] <- 1
## classesSamp[!is.na(bambooSamp)] <- 2
## classesSamp[!is.na(baresoilSamp)] <- 3
## # ....continue for all sampled classes
## # check number of samples per class (should be equal!)
## freq(classSamp)
## # or
## hist(classSamp)
## 
## 
## # load in the image data and make a brick as done with the RandomForest classification
## 
## 
## 
## # include only pixels sampled
## trainBrick <- mask(gewata, classSamp)
## 
## # add the layer with classes to the training brick
## trainBrick <- addLayer(trainBrick, classSamp)
## 
## 
## # construct a value table
## valuetable <- getValues(trainBrick)
## valuetable <- as.data.frame(trainBrick)
## 
## 
## # continue with RandomForest classification
## 
## 
## 


