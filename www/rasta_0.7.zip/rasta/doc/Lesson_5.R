### R code from vignette source 'Lesson_5.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: Lesson_5.Rnw:79-82
###################################################
# Example to perform system set-up checks
library(rgdal)
getGDALVersionInfo()


###################################################
### code chunk number 2: Lesson_5.Rnw:105-111
###################################################
library(raster)
# Generate a RasterLAyer object
r <- raster(ncol=40, nrow=20)
class(r) 
# Simply typing the object name displays its general properties / metadata
r


###################################################
### code chunk number 3: Lesson_5.Rnw:116-125
###################################################
# Using the previously generated RasterLAyer object
# Let's first put some values in the cells of the layer
r[] <- rnorm(n=ncell(r))
# Create a RasterStack objects with 3 layers
s <- stack(x=c(r, r*2, r))
# The exact same procedure works for creating a RasterBrick
b <- brick(x=c(r, r*2, r))
# Let's look at the properties of of one of these two objects
b


###################################################
### code chunk number 4: Lesson_5.Rnw:136-139
###################################################
# Reading a multilayer raster object
gewata <- brick(system.file("extdata/LE71700552001036SGS00_SR_Gewata_INT1U.tif",
                            package="rasta"))


###################################################
### code chunk number 5: Lesson_5.Rnw:142-143
###################################################
gewata


###################################################
### code chunk number 6: Lesson_5.Rnw:147-150 (eval = FALSE)
###################################################
## gewataB1 <- raster(system.file("extdata/LE71700552001036SGS00_SR_Gewata_INT1U.tif",
##                                package="rasta"))
## gewataB1


###################################################
### code chunk number 7: Lesson_5.Rnw:163-166 (eval = FALSE)
###################################################
## # PLot the first layer of the RasterBrick
## plot(gewata, 1)
## e <- drawExtent(show=TRUE)


###################################################
### code chunk number 8: Lesson_5.Rnw:171-175 (eval = FALSE)
###################################################
## # Crop gewata using e
## gewataSub <- crop(gewata, e)
## # Now visualize the new cropped object
## plot(gewataSub, 1)


###################################################
### code chunk number 9: Lesson_5.Rnw:182-189 (eval = FALSE)
###################################################
## # start by making sure that your working directory is properly set
## # If not you can set it using setwd()
## getwd()
## download.file(url='http://rasta.r-forge.r-project.org/tura.zip', destfile='tura.zip')
## unzip(zipfile='tura.zip')
## # Retrieve the content of the tura sub-directory
## list <- list.files(path='tura/', full.names=TRUE)


###################################################
### code chunk number 10: Lesson_5.Rnw:192-193 (eval = FALSE)
###################################################
## plot(raster(list[1]))


###################################################
### code chunk number 11: Lesson_5.Rnw:196-198 (eval = FALSE)
###################################################
## turaStack <- stack(list)
## turaStack


###################################################
### code chunk number 12: Lesson_5.Rnw:201-203 (eval = FALSE)
###################################################
## # Write this file at the root of the working directory
## writeRaster(x=turaStack, filename='turaStack.grd', datatype='INT2S')


###################################################
### code chunk number 13: Lesson_5.Rnw:221-222
###################################################
ndvi <- (gewata[[4]] - gewata[[3]]) / (gewata[[4]] + gewata[[3]])


###################################################
### code chunk number 14: ndvi
###################################################
plot(ndvi)


###################################################
### code chunk number 15: Lesson_5.Rnw:242-249
###################################################
# Define the function to calculate NDVI from 
ndvCalc <- function(x) {
  ndvi <- (x[[4]] - x[[3]]) / (x[[4]] + x[[3]])
  return(ndvi)
}
ndvi2 <- calc(x=gewata, fun=ndvCalc)



###################################################
### code chunk number 16: Lesson_5.Rnw:253-258
###################################################
ndvOver <- function(x, y) {
  ndvi <- (y - x) / (x + y)
  return(ndvi)
}
ndvi3 <- overlay(x=gewata[[3]], y=gewata[[4]], fun=ndvOver)


###################################################
### code chunk number 17: Lesson_5.Rnw:262-264
###################################################
all.equal(ndvi, ndvi2)
all.equal(ndvi, ndvi3)


###################################################
### code chunk number 18: Lesson_5.Rnw:272-274
###################################################
# One single line is sufficient to project any raster to any projection
ndviLL <- projectRaster(ndvi, crs='+proj=longlat')


###################################################
### code chunk number 19: Lesson_5.Rnw:282-289 (eval = FALSE)
###################################################
## # Since this function will write a file to your working directory
## # you want to make sure that it is set where you want the file to be written
## # It can be changed using setwd()
## getwd()
## # Note that we are using the filename argument, contained in the elypsis of 
## # the function, since we want to write the output directly to file.
## KML(x=ndviLL, filename='gewataNDVI.kml')


###################################################
### code chunk number 20: Lesson_5.Rnw:303-306
###################################################
library(rasta)
data(taravao)
taravao


###################################################
### code chunk number 21: Lesson_5.Rnw:311-315
###################################################
# Generate the cloud mask using QA2cloud wrapped into calc()
cloud <- calc(taravao[[9]], fun=QA2cloud) 
# Replace 0s by NAs (to improve visual display)
cloud[cloud == 0] <- NA 


###################################################
### code chunk number 22: rgb
###################################################
# Display data and the cloud mask 
plotRGB(taravao, 5, 3, 4) 
# Note the clouds at the top and bottom of the image.
# Let's plot the cloud mask over them and see how they match
plot(cloud, add=TRUE, legend=FALSE)


###################################################
### code chunk number 23: Lesson_5.Rnw:337-340
###################################################
taravao8 <- dropLayer(x=taravao, i=9)
# Let's duplicate that RasterStack and save it for later
taravao8_2 <- taravao8


###################################################
### code chunk number 24: Lesson_5.Rnw:345-346
###################################################
taravao8[cloud == 1] <- NA


###################################################
### code chunk number 25: Lesson_5.Rnw:349-354
###################################################
cloud2NA <- function(x, y){
  x[y == 1] <- NA
  return(x)
}
taravao8_3 <- overlay(taravao8_2, cloud, fun=cloud2NA)


###################################################
### code chunk number 26: Lesson_5.Rnw:367-381 (eval = FALSE)
###################################################
## library(MODIS)
## # Get a list of sds names
## sds <- getSds('full/path/filename.hdf')
## # Isolate the name of the first sds
## name <- sds$SDS4gdal[1]
## # Optional: In case a sds name contains spaces, these 2 steps remove them
## name <- gsub("\"", "", name)
## name <- sprintf('\"%s\"', name)
## # Define output filename and create gdal_translate command
## filename <- 'name/of/output/file.tif'
## translate <- sprintf('gdal_translate %s %s', name, filename)
## system(translate)
## # Load the Geotiff created into R
## r <- raster(filename)


###################################################
### code chunk number 27: Lesson_5.Rnw:386-391 (eval = FALSE)
###################################################
## library(MODIS)
## # Get a list of sds names
## sds <- getSds('full/path/filename.hdf')
## # Any sds can then be read directly using the raster function
## r <- raster(sds$SDS4gdal[1])


