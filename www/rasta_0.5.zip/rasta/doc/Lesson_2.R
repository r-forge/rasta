### R code from vignette source 'Lesson_2.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: preliminaries
###################################################
options(width = 70, prompt = ">", continue = "+ ")


###################################################
### code chunk number 2: Lesson_2.Rnw:75-79 (eval = FALSE)
###################################################
## setwd("yourworkingdirectory")
## #This sets the working directory (where R looks for files)
## #getwd() 
## # Double check your working directory


###################################################
### code chunk number 3: Lesson_2.Rnw:82-83
###################################################
datdir <- file.path("data") ## path


###################################################
### code chunk number 4: loadlibraries
###################################################
#----Packages for Reading/Writing/Manipulating Spatial Data---
library(rgdal) # reading shapefiles and raster data
library(rgeos)
library(maptools)
library(spdep)   # useful spatial stat functions
library(spatstat) # functions for generating random points
library(raster) 
#---Packages for Data Visualization and Manipulation---
library(ggplot2)
library(reshape2)
library(scales)


###################################################
### code chunk number 5: Lesson_2.Rnw:118-122 (eval = FALSE)
###################################################
## download.file('http://rasta.r-forge.r-project.org/kenyashape.zip',  
##       file.path(datdir, 'kenyashape.zip'))
## unzip(file.path(datdir, 'kenyashape.zip'), exdir = datdir)
## kenya <- readOGR(dsn = datdir, layer = 'kenya')


###################################################
### code chunk number 6: Lesson_2.Rnw:136-137 (eval = FALSE)
###################################################
## plot(kenya)


###################################################
### code chunk number 7: kenya
###################################################
library(rasta)
data("kenya")
plot(kenya)


###################################################
### code chunk number 8: exploredata
###################################################
summary(kenya)
str(kenya,2)


###################################################
### code chunk number 9: accessdata
###################################################
#--------------------------ACCESS THE SHAPEFILE DATA------------------------------
dsdat <- as(kenya, "data.frame")  # extract the data into a regular data.frame
head(dsdat)
kenya$new <- 1:nrow(dsdat) # add a new colunm, just like adding data to a data.frame
head(kenya@data)


###################################################
### code chunk number 10: readcsv
###################################################
#--------------------------READ AND EXPLORE A CSV------------------------------
filepath <- system.file("extdata/kenpop89to99.csv", package ="rasta")
d <- read.csv(filepath)


###################################################
### code chunk number 11: csvclean
###################################################
#--------------------------EXTRACT COLUMNS FROM CSV------------------------------
d <- d[,c('ip89DId','PopChg','BrateChg','Y89Pop','Y99Pop')] 
#Grab only the colunms we want
names(d)
#str(d)
nrow(d)
d <- unique(d)  #get rid of duplicate rows
nrow(d) #note we now have less rows


###################################################
### code chunk number 12: tablejoin
###################################################
#----------------EXPLORE MERGE AND DO A TABLE JOIN------------------------------
#--------------------First a basic Merge Just to Demonstrate-------------
d2 <- kenya@data
d3 <- merge(d,d2) 
#They have common colunm names so we don't have to specify what to join on
head(d3)
d4 <- merge(d,kenya) #This will produce the same result.
head(d4)
#--------------Now lets do the Table Join: Join csv data to our Shapefile-----
#--We can do the join in one line by using the match() function
ds1 <- kenya #make a copy so we can demonstrate 2 ways of doing the join

kenya@data <- data.frame(as(kenya,'data.frame'),
                    d[match(kenya@data[,'ip89DId'], d[,'ip89DId']),])


###################################################
### code chunk number 13: Lesson_2.Rnw:257-266 (eval = FALSE)
###################################################
## #---Alternativley we can do this :
## #This is the preferred method but will only work if kenya and d have 
## # the same number of rows, and the row names are identical and in the same order
## row.names(d) <- d$ip89DId
## row.names(ds1) <- as.character(ds1$ip89DId)
## d <- d[order(d$ip89DId),]
## ds1 <- spCbind(ds1,d)
## 
## head(kenya@data)


###################################################
### code chunk number 14: ranpoints
###################################################
#--------------------------GENERATE RANDOM POINTS------------------------------
win <- bbox(kenya) #the bounding box around the Kenya dataset
win
win <- t(win) #transpose the bounding box matrix
win
win <- as.vector(win) #convert to a vector for input into runifpoint()
win
dran1 <- runifpoint(100, win = as.vector(t(bbox(kenya)))) #create 100 random points


###################################################
### code chunk number 15: alternative
###################################################
win <- extent(kenya)
dran2 <- runifpoint(n = 100, win = as.vector(win))


###################################################
### code chunk number 16: rndp_kenya
###################################################
plot(kenya)
plot(dran1, add = TRUE, col = "red")
plot(dran2, add = TRUE, col = "blue", pch = 19, cex = 0.5)


###################################################
### code chunk number 17: converttocoordinatestextfile
###################################################
#--------------------------CONVERT RANDOM POINTS TO DATA.FRAME------------------
dp <- as.data.frame(dran1) 
#This creates a simple data frame with 2 colunms, x and y
head(dp)
#Now we will add some values that will be aggregated in the next exercise
dp$values<-rnorm(100,5,10) 
#generates 100 values from a Normal distribution with mean 5, and sd-10
head(dp)


###################################################
### code chunk number 18: converttospatialpoints
###################################################
#--------------------------CONVERT RANDOM POINTS TO SPATIAL POINTS DATAFRAME----
dsp <- SpatialPointsDataFrame(coords = dp[,c('x','y')], 
	data = data.frame('values' = dp$values))
summary(dsp)

#---Since the Data was Generated from a source with same projection as our Kenya data, 
#---we will go ahead and define the projection"
dsp@proj4string <- kenya@proj4string


###################################################
### code chunk number 19: overlay
###################################################
#--------------------------POINT IN POLY JOIN------------------------------

#--The data frame tells us for each point the index of the polygon it falls into
dsdat <- over(kenya, dsp, fn = mean) #do the join
head(dsdat) #look at the data

inds <- row.names(dsdat) 
#get the row names of dsdat so that we can put the data back into ds
head(inds)

str(kenya@data)
kenya@data[inds, 'pntvals'] <- dsdat 
#use the row names from dsdata to add the aggregated point values to ds@data
head(kenya@data)


###################################################
### code chunk number 20: raster
###################################################
#--------------------------READ AND CROP A RASTER--
library(rasta)
filepath <- system.file("extdata", "anom.2000.03.tiff", package ="rasta")
g <- raster(filepath)
# plot
plot(g)
plot(kenya, add = TRUE) #plot kenay on top to get some sense of the extent


###################################################
### code chunk number 21: crop
###################################################
#------Crop the Raster Dataset to the Extent of the Kenya Shapefile
gc <- crop(g, kenya) #clip the raster to the extent of the shapefile
#Then test again to make sure they line up
plot(gc)
plot(kenya, add = TRUE)


###################################################
### code chunk number 22: rasterextract (eval = FALSE)
###################################################
## #--------------------------PIXEL IN POLY SPATIAL JOIN------------------------------
## #Unweighted- only assigns grid to district if centroid is in that district
## kenya@data$precip <- extract(gc, kenya, fun = mean, weights=FALSE) 


###################################################
### code chunk number 23: Lesson_2.Rnw:401-404 (eval = FALSE)
###################################################
## kenya@data$precip_wght <- extract(gc, kenya, fun = mean, weights = TRUE) 
## #If you want to see the actual values and the weights associated with them do this:
## rastweight <- extract(gc, kenya, weights = TRUE)


###################################################
### code chunk number 24: fortify
###################################################
#------------------PREP SPATIAL DATA FOR GGPLOT WITH FORTIFY()------------
pds <- fortify(kenya, region='ip89DId') #convert to form readable by ggplot2
pds$ip89DId <- as.integer(pds$id)
head(pds)


###################################################
### code chunk number 25: gg1
###################################################
#--------------------------MAKE A BASIC MAP------------------------------
p1 <- ggplot(d)
p1 <- p1 + geom_map(aes(fill = PopChg, map_id = ip89DId), map = pds) 
p1 <- p1 + expand_limits(x = pds$long, y = pds$lat) 
#this is sometimes necessary to keep from throwin an error
p1 <- p1 + coord_equal() #this keeps the map from having that 'squished' look 
p1


###################################################
### code chunk number 26: gg2
###################################################
#---------------------CHANGE THE COLOR SCHEME, TWEAK THE LEGEND------------
#---Change the Colour Scheme-----
p1 <- p1 + scale_fill_gradient(name='Population \nChange', 
              low ='wheat', high = 'steelblue') 
#to set break points, enter in breaks=c(...,..)
#The \n in Population \nChange' indicates a carriage return
p1


###################################################
### code chunk number 27: gg3
###################################################
#-----------------------EDIT THE BACKGROUND------------------------------
#-----Get Rid of the Background-----
#Blank Grid, Background,Axis,and Tic Marks
bGrid<-theme(panel.grid = element_blank())
bBack<-theme(panel.background = element_blank())
bAxis<-theme(axis.title.y = element_blank())
bTics<-theme(axis.text = element_blank(), axis.text.y = element_blank(), 
	axis.ticks = element_blank())
p1<-p1 + bAxis + bTics + bGrid + bBack + xlab('')
p1


###################################################
### code chunk number 28: gg4
###################################################
#--------------------------ADD SOME LABELS--------------------------------------
#--------Add Some Polygon labels------
#-Polygon Labels
cens <- as.data.frame(coordinates(kenya)) #extract the coordinates for centroid of each polygon
cens$Region <- kenya$ip89DName
cens$ip89DId <- kenya$ip89DId
head(cens)  #we will use this file to label the polygons
p1 <- p1 + geom_text(data = cens, aes(V1,V2,label = Region), size = 2.5, vjust=1) +
  labs(title='Population Change in Kenya \n (1989-1999)')
p1 


###################################################
### code chunk number 29: gg5
###################################################
#-----Add Some value Labels------------
pdlab <- merge(cens,d) #Merge the centroids without data
head(pdlab) #We will use this to label the polygons with their data values
p1 <- p1 + geom_text(data = pdlab, 
  aes(V1, V2, label = paste("(",PopChg,")",sep="")),
                     colour = "black" ,size = 2,vjust = 3.7)
p1


###################################################
### code chunk number 30: fgg1
###################################################
#--------------------------RESHAPE THE DATA AND MAKE A PANEL MAP----------------
pd <- d[,c('ip89DId','Y89Pop','Y99Pop')] #select out certain colunms
pd <- melt(pd, id.vars='ip89DId') # convert the data to 'long' form
head(pd) # take a look at the data

pmap <- ggplot(pd)
p2 <- pmap + geom_map(aes(fill = value,map_id = ip89DId), map=pds) + 
		facet_wrap(~variable)
p2 <- p2 + expand_limits(x = pds$lon, y = pds$lat) + coord_equal()
p2 + labs(title='Basic Panel Map')


###################################################
### code chunk number 31: fgg2
###################################################
#--------------------------TWEAK THE PANEL MAP----------------------------------
#If we want to stack the panels vertically we change the options in facet_wrap()
p2 <- p2 + facet_wrap(~variable, ncol=1) #have only 1 colunm of panels


###################################################
### code chunk number 32: fgg3
###################################################
#--------------------------MORE PANEL MAP TWEAKS------------------------------
#--We can add all the other tweaks as before
p2 <- p2 + scale_fill_gradient(name='Population',low ='wheat',high = 'steelblue') 
#to set break points, enter in
p2 <- p2 + bAxis+bGrid+bTics+bBack
p2 <- p2 + theme(panel.border=element_rect(fill=NA)) 
#this removes the background but keeps aborder around the panels
#--We can also adjust the format, theme, et cetera of the panel lables with 'strip.text.x'
p2 <- p2 + theme(strip.background=element_blank(),strip.text.x=element_text(size=12))
p2
#===============================================================================


###################################################
### code chunk number 33: ex (eval = FALSE)
###################################################
## #---Set up the data for ggplot
## df <- rasterToPoints(gc) #convert the raster to a points object
## df <- data.frame(df) #and then to a data.frame
## pds <- fortify(kenya,region='ip89DId')
## str(df)
## p<-ggplot(pds)+geom_raster(data=df,aes(x=x,y=y,fill=anom.2000.03))+theme_bw() #use geom_raster 
## p<-p+geom_map(map=pds,aes(map_id=id,x=long,y=lat),fill=NA,colour='black') #then plot a map, with fill=NA so we can see the raster values
## p<-p+coord_equal()
## p<-p+scale_fill_gradient(low='wheat',high='blue') #adjust the colors
## p<-p+labs(x='Longitude',y='Latidude')
## p
## 


