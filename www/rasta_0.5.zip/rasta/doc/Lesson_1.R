### R code from vignette source 'Lesson_1.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: preliminaries
###################################################
options(width = 70, prompt = ">", continue = "+ ")


###################################################
### code chunk number 2: Lesson_1.Rnw:172-174
###################################################
rm(list=ls())  # Clear the workspace!
ls() ## no objects left in the workspace


###################################################
### code chunk number 3: Lesson_1.Rnw:178-180
###################################################
a <- 1
a


###################################################
### code chunk number 4: Lesson_1.Rnw:192-193
###################################################
class(a)


###################################################
### code chunk number 5: Lesson_1.Rnw:202-214
###################################################
add <- function(x){ 
#put the function arguments in () and the evaluation in {}
  x + 1
}
add(4) 

# Set the default values for your function--
add <- function(x = 5){
  x + 1
}
add()  #automatically evaluates x = 5
add(6) #but you can still change the defaults


###################################################
### code chunk number 6: Lesson_1.Rnw:224-231
###################################################
newfunc <- function(x, y) {
  2*x + y
} 

a2b <- newfunc(2, 4)
a2b
rm(a, newfunc, a2b)


###################################################
### code chunk number 7: Lesson_1.Rnw:266-267 (eval = FALSE)
###################################################
## install.packages("rasta", repos="http://R-Forge.R-project.org")


###################################################
### code chunk number 8: Lesson_1.Rnw:269-270
###################################################
library(rasta) ## load the rasta library


###################################################
### code chunk number 9: Lesson_1.Rnw:273-275 (eval = FALSE)
###################################################
## # ?mysummary
## mysummary


###################################################
### code chunk number 10: readcsvexample
###################################################
f <- system.file("extdata/kenpop89to99.csv", package ="rasta")
print(f)
mydat<-read.csv(f)


###################################################
### code chunk number 11: explore
###################################################
names(mydat)[1:3] #colunm names
summary(mydat$Y89Pop)[1:3]
head(mydat$Y89Births)[1:2]


###################################################
### code chunk number 12: regression
###################################################
myreg<-lm(Y99Pop ~ Y89Births + Y89Brate, data = mydat) 
myreg[c(1,8)]


###################################################
### code chunk number 13: Lesson_1.Rnw:326-331
###################################################
names(myreg)[1:3]
myregsum <- summary(myreg)
names(myregsum)[1:2]
myregsum[['adj.r.squared']] #extract the adjusted r squared
myregsum$adj.r.squared # does the same thing


###################################################
### code chunk number 14: Lesson_1.Rnw:352-355 (eval = FALSE)
###################################################
## setwd("yourworkingdirectory")
## # This sets the working directory (where R looks for files)
## getwd() # Double check your working directory


###################################################
### code chunk number 15: Lesson_1.Rnw:358-359
###################################################
datdir <- file.path("data") ## path


###################################################
### code chunk number 16: Lesson_1.Rnw:381-383
###################################################
## Load required packages
library(raster)


###################################################
### code chunk number 17: Lesson_1.Rnw:386-395
###################################################
## Download data from gadm.org 
require(raster)
if (!file.exists(datdir)) { dir.create(datdir)}
if (!file.exists(file.path(datdir, "PHL_adm2.RData"))) {
  adm <- getData('GADM', country = 'PHL', level=2, path = 'data/')
} else {
  load(file.path(datdir, "PHL_adm2.RData"))
  adm <- gadm
}


###################################################
### code chunk number 18: Lesson_1.Rnw:398-400 (eval = FALSE)
###################################################
## ## Download data from gadm.org 
## adm <- getData('GADM', country='PHL', level=2, path = datdir)


###################################################
### code chunk number 19: phil
###################################################
mar <- adm[adm$NAME_1=="Marinduque",]
plot(mar, bg="dodgerblue", axes=T)
plot(mar, lwd=10, border="skyblue", add=T)
plot(mar, col="green4", add=T)
grid()
box()
invisible(text(getSpPPolygonsLabptSlots(mar), 
labels=as.character(mar$NAME_2), cex=1.1, col="white", font=2))
mtext(side=3, line=1, "Provincial Map of Marinduque", cex=2)
mtext(side=1, "Longitude", line=2.5, cex=1.1)
mtext(side=2, "Latitude", line=2.5, cex=1.1) 
text(122.08,13.22, "Projection: Geographic\n
Coordinate System: WGS 1984\n
Data Source: GADM.org\n
Created by: ARSsalvacion", adj=c(0,0), cex=0.7, col="grey20")


###################################################
### code chunk number 20: ggplotphil (eval = FALSE)
###################################################
## require(ggmap)
## shp.spdf <- adm[adm$NAME_1=="Marinduque",]
## shp.df <- fortify(shp.spdf)
## shp.centroids.df <- data.frame(long = coordinates(shp.spdf)[,1], 
##                                lat = coordinates(shp.spdf)[,2])
## # Get names and id numbers corresponding to administrative areas
## shp.centroids.df[, 'ID_1'] <- shp.spdf@data[,'ID_1']
## shp.centroids.df[, 'NAME_2'] <- shp.spdf@data[,'NAME_2']
## q <- qmap(location = "Marinduque", zoom = 10, maptype = "satellite")
## q = q +  geom_polygon(aes(x = long, y = lat, group = group), 
##     data = shp.df, 
##     colour = 'white', fill = 'black', alpha = .4, size = .3) 
## 
## q = q + geom_text(data = shp.centroids.df, 
##     aes(label = NAME_2, x = long, y = lat, group = NAME_2), 
##                   size = 3, colour= "white")
## print(q)


