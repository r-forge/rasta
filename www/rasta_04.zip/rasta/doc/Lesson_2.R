### R code from vignette source 'Lesson_2.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: Lesson_2.Rnw:35-36
###################################################
options(width=60)


###################################################
### code chunk number 2: Lesson_2.Rnw:72-78 (eval = FALSE)
###################################################
## setwd("yourworkingdirectory")
## # This sets the working directory (where R looks for files)
## 
## getwd() # Double check your working directory
## datdir <- "data/" #This is an example of a Mac file path
## # datdir<- "/data/" #This is an example of a PC file path


###################################################
### code chunk number 3: loadlibraries
###################################################
#----Packages for Reading/Writing/Manipulating Spatial Data---
library(rgdal) # reading shapefiles and raster data
library(rgeos)
library(maptools)
library(spdep)   # useful spatial stat functions
library(spatstat) # functions for generating random points
library(raster) 
#---Packages for Data Visualization and Manipulation---
library(ggplot2)
library(reshape2)
library(scales)


###################################################
### code chunk number 4: Lesson_2.Rnw:113-117 (eval = FALSE)
###################################################
## download.file('http://rasta.r-forge.r-project.org/kenyashape.zip',  
##       'data/kenyashape.zip')
## unzip('data/kenyashape.zip', exdir = datdir)
## kenya <- readOGR(dsn = datdir, layer = 'kenya')


###################################################
### code chunk number 5: Lesson_2.Rnw:131-132 (eval = FALSE)
###################################################
## plot(kenya)


###################################################
### code chunk number 6: kenya
###################################################
library(rasta)
data("kenya")
plot(kenya)


###################################################
### code chunk number 7: exploredata
###################################################
summary(kenya)
str(kenya,2)


###################################################
### code chunk number 8: accessdata
###################################################
#--------------------------ACCESS THE SHAPEFILE DATA------------------------------
dsdat<-as(kenya, "data.frame")  #extract the data into a regular data.frame
head(dsdat)

kenya$new<- 1:nrow(dsdat) #add a new colunm, just like adding data to a data.frame
head(kenya@data)


###################################################
### code chunk number 9: ranpoints
###################################################
#--------------------------GENERATE RANDOM POINTS------------------------------
win<-bbox(kenya) #the bounding box around the Kenya dataset
win
win<-t(win) #transpose the bounding box matrix
win
win<-as.vector(win) #convert to a vector for input into runifpoint()
win
dran<-runifpoint(100,win=as.vector(t(bbox(kenya)))) #create 100 random points


###################################################
### code chunk number 10: rndp_kenya
###################################################
plot(kenya)
plot(dran,add=T)


###################################################
### code chunk number 11: converttocoordinatestextfile
###################################################
#--------------------------CONVERT RANDOM POINTS TO DATA.FRAME------------------
dp <- as.data.frame(dran) #This creates a simple data frame with 2 colunms, x and y
head(dp)

# Now we will add some values that will be aggregated in the next exercise
dp$values<-rnorm(100,5,10) 
#generates 100 values from a Normal distribution with mean 5, and sd-10
head(dp)


