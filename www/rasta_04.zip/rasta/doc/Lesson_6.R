### R code from vignette source 'Lesson_6.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: Lesson_6.Rnw:60-66
###################################################
# load the necessary packages
library(rasta)
library(raster)
library(rgdal)
library(sp)
library(ggplot2)


###################################################
### code chunk number 2: Lesson_6.Rnw:92-109
###################################################
# load in the data
data(GewataB2)
data(GewataB3)
data(GewataB4)
# check out the attributes
GewataB2
# some basic statistics using cellStats()
cellStats(GewataB2, stat=max)
# ...is equivalent to:
maxValue(GewataB2)
# what is the maximum value of all three bands?
max(c(maxValue(GewataB2), maxValue(GewataB3), maxValue(GewataB4)))

# plot the histograms of all bands
hist(GewataB2)
hist(GewataB3)
hist(GewataB4)


###################################################
### code chunk number 3: Lesson_6.Rnw:114-118
###################################################
library(rasterVis)
gewata <- brick(GewataB2, GewataB3, GewataB4)
# view all histograms together with rasterVis
histogram(gewata)


###################################################
### code chunk number 4: Lesson_6.Rnw:123-124
###################################################
splom(gewata)


###################################################
### code chunk number 5: Lesson_6.Rnw:129-130
###################################################
splom(gewata)


###################################################
### code chunk number 6: Lesson_6.Rnw:151-152
###################################################
ndvi <- (GewataB4 - GewataB3) / (GewataB4 + GewataB3)


###################################################
### code chunk number 7: Lesson_6.Rnw:157-158 (eval = FALSE)
###################################################
## ndvi <- overlay(GewataB4, GewataB3, fun=function(x,y){(x-y)/(x+y)})


###################################################
### code chunk number 8: Lesson_6.Rnw:165-174 (eval = FALSE)
###################################################
## # first, plot the raster
## plot(ndvi)
## # call drawExtent() to activate interactive mode
## # and assign the result to an extent object e
## e <- drawExtent()
## # now click 2 points on the plot window
## # these represent the top-right and bottom-left corner of your extent
## # now plot ndvi again, but only the extent you defined interactively
## plot(ndvi, ext=e)


###################################################
### code chunk number 9: Lesson_6.Rnw:190-194
###################################################
# load the data
data(vcfGewata)
plot(vcfGewata)
histogram(vcfGewata) # or 'hist(vcfGewata)'


###################################################
### code chunk number 10: Lesson_6.Rnw:199-202
###################################################
vcfGewata[vcfGewata > 100] <- NA
plot(vcfGewata)
histogram(vcfGewata)


###################################################
### code chunk number 11: Lesson_6.Rnw:207-216
###################################################
ndvi <- calc(ndvi, fun = function(x) floor(x*10000))
# change the data type
# see ?dataType for more info
dataType(ndvi) <- "INT2U"
# name this layer to make plots interpretable
names(ndvi) <- "NDVI"
# make the covariate rasterBrick
covs <- addLayer(gewata, ndvi, vcfGewata)
plot(covs)


###################################################
### code chunk number 12: Lesson_6.Rnw:221-228
###################################################
# load the training polygons
data(trainingPoly)
# inspect the data
trainingPoly@data
# superimpose training polygons onto ndvi plot
plot(ndvi)
plot(trainingPoly, add = TRUE)


###################################################
### code chunk number 13: Lesson_6.Rnw:233-243
###################################################
# define a reclassification function
reclass <- function(x){
  y <- ifelse(x == "forest", 1,
              ifelse(x == "cropland", 2, 3)
              )
  return(y)
}
# apply this over the trainingPoly data slot
trainingPoly@data$Code <- sapply(trainingPoly@data$Class, 
                                 FUN = function(x) reclass(x))


###################################################
### code chunk number 14: Lesson_6.Rnw:248-251
###################################################
classes <- rasterize(trainingPoly, ndvi, field = 'Code')
dataType(classes) <- "INT1U"
plot(classes, col = c("dark green", "orange", "light blue"))


###################################################
### code chunk number 15: Lesson_6.Rnw:258-264
###################################################
covmasked <- mask(covs, classes)
plot(covmasked)
# add the classes layer to this new brick
names(classes) <- "class"
trainingbrick <- addLayer(covmasked, classes)
plot(trainingbrick)


###################################################
### code chunk number 16: Lesson_6.Rnw:269-275
###################################################
# extract all values into a matrix
valuetable <- getValues(trainingbrick)
# convert to a data.frame and inspect the first and last rows
valuetable <- as.data.frame(valuetable)
head(valuetable)
tail(valuetable)


###################################################
### code chunk number 17: Lesson_6.Rnw:280-286
###################################################
# keep only rows where valuetable$classes has a value
valuetable <- valuetable[!is.na(valuetable$class),]
head(valuetable)
tail(valuetable)
# convert values in the class column to factors
valuetable$class <- factor(valuetable$class, levels = c(1:3))


###################################################
### code chunk number 18: Lesson_6.Rnw:291-315
###################################################
# 1. NDVI
ggplot(data = valuetable, aes(x = NDVI)) + 
  geom_histogram() + 
  facet_wrap(~ class) +
  theme_bw()

# 2. VCF
ggplot(data = valuetable, aes(x = vcf2000Gewata)) +
  geom_histogram() +
  labs(x = "% Tree Cover") +
  facet_wrap(~ class) +
  theme_bw()

# 3. Bands 3 and 4
ggplot(data = valuetable, aes(x = gewataB3, y = gewataB4)) +
  stat_bin2d() +
  facet_wrap(~ class) +
  theme_bw()

# 4. Bands 2 and 3
ggplot(data = valuetable, aes(x = gewataB2, y = gewataB3)) +
  stat_bin2d() +
  facet_wrap(~ class) +
  theme_bw()


###################################################
### code chunk number 19: Lesson_6.Rnw:322-327
###################################################
# NA values are not permitted in the covariates/predictor columns
# which rows have NAs in them?
delRows <- which(apply(valuetable, 1, FUN = function(x) NA %in% x))
# remove these rows from valuetable
valuetable <- valuetable[-delRows,]


###################################################
### code chunk number 20: Lesson_6.Rnw:329-334 (eval = FALSE)
###################################################
## # construct a random forest model
## # caution: this step takes fairly long!
## library(randomForest)
## modelRF <- randomForest(x = valuetable[,c(1:5)], y = valuetable$class,
##                         importance = TRUE)


###################################################
### code chunk number 21: Lesson_6.Rnw:336-344
###################################################
library(randomForest)
if(!file.exists("data/modelRF.rda")){
  modelRF <- randomForest(x = valuetable[,c(1:5)], y = valuetable$class,
                        importance = TRUE)
  save(modelRF, file='data/www/modelRF.rda', compress="bzip2", ascii=FALSE)
} else {
  load('data/modelRF.rda')
}


###################################################
### code chunk number 22: Lesson_6.Rnw:351-357
###################################################
# inspect the structure and element names of the resulting model
class(modelRF)
str(modelRF)
names(modelRF)
# inspect the confusion matrix of the OOB error assessment
modelRF$confusion


###################################################
### code chunk number 23: Lesson_6.Rnw:362-363
###################################################
varImpPlot(modelRF)


###################################################
### code chunk number 24: Lesson_6.Rnw:372-380
###################################################
# check layer and column names
names(covs)
names(valuetable)
# predict land cover using the RF model
predLC <- predict(covs, model=modelRF, na.rm=TRUE)
# plot the results
# recall: 1 = forest, 2 = cropland, 3 = wetland
plot(predLC, col=c("dark green", "orange", "light blue"))


###################################################
### code chunk number 25: Lesson_6.Rnw:384-385
###################################################
plot(predLC, col=c("dark green", "orange", "light blue"))


###################################################
### code chunk number 26: Lesson_6.Rnw:399-401
###################################################
valuetable <- getValues(covs)
head(valuetable)


###################################################
### code chunk number 27: Lesson_6.Rnw:406-407 (eval = FALSE)
###################################################
## km <- kmeans(na.omit(valuetable), centers = 3, iter.max = 100, nstart = 10)


###################################################
### code chunk number 28: Lesson_6.Rnw:409-415
###################################################
if(!file.exists('data/km.rda')){
  km <- kmeans(na.omit(valuetable), centers = 3, iter.max = 100, nstart = 10)
  save(km, file='data/km.rda', compres='bzip2', ascii=FALSE)
} else {
  load('data/km.rda')
}


###################################################
### code chunk number 29: Lesson_6.Rnw:417-420
###################################################
# km contains the clusters (classes) assigned to the cells
head(km$cluster)
unique(km$cluster) # displays unique values


###################################################
### code chunk number 30: Lesson_6.Rnw:425-436
###################################################
# create a blank raster with NA values
rNA <- setValues(raster(covs), NA)
# loop through layers of covs
# assign a 1 wherever an NA is enountered
for(i in 1:nlayers(covs)){
  rNA[is.na(covs[[i]])] <- 1
}
# convert rNA to an integer vector
rNA <- getValues(rNA)
# substitue the NA's for 0's
rNA[is.na(rNA)] <- 0


###################################################
### code chunk number 31: Lesson_6.Rnw:443-449
###################################################
# convert valuetable to a data.frame
valuetable <- as.data.frame(valuetable)
# assign the cluster values (where rNA != 1)
valuetable$class[rNA==0] <- km$cluster
# assign NA to this column elsewhere
valuetable$class[rNA==1] <- NA


###################################################
### code chunk number 32: Lesson_6.Rnw:454-459
###################################################
# create a blank raster
classes <- raster(covs)
# assign values from the 'class' column of valuetable
classes <- setValues(classes, valuetable$class)
plot(classes, col=c("dark green", "orange", "light blue"))


###################################################
### code chunk number 33: Lesson_6.Rnw:464-465
###################################################
plot(classes, col=c("dark green", "orange", "light blue"))


###################################################
### code chunk number 34: Lesson_6.Rnw:478-485
###################################################
# Make an empty raster based on the LC raster attributes
formask <- raster(predLC)
# assign NA to all cells
formask <- setValues(formask, value = NA)
# assign 1 to all cells corresponding to the forest class
formask[predLC==1] <- 1
plot(formask, col = "dark green", legend = FALSE)


###################################################
### code chunk number 35: Lesson_6.Rnw:494-502
###################################################
# make an empty raster
sievemask <- setValues(raster(formask), NA)
# assign a value of 1 for all forest pixels
sievemask[!is.na(formask)] <- 1
# sum of all neighbourhood pixels
sievemask <- focal(sievemask, w=3, fun=sum, na.rm=TRUE)
sievemask
histogram(sievemask)


###################################################
### code chunk number 36: Lesson_6.Rnw:507-518
###################################################
# copy the original forest mask
formaskSieve <- formask
# assign NA to pixels where the sievemask == 1/9
formaskSieve[sievemask==1/9] <- NA
# zoom in to a small extent to check the results
# Note: you can define your own by using e <- drawExtent()
e <- extent(c(811744.8, 812764.3, 849997.8, 850920.3))
par(mfrow=c(1, 2)) # allow 2 plots side-by-side
plot(formask, ext=e, col="dark green", legend=FALSE)
plot(formaskSieve, ext=e, col="dark green", legend=FALSE)
par(mfrow=c(1, 1)) # reset plotting window


###################################################
### code chunk number 37: Lesson_6.Rnw:523-527
###################################################
par(mfrow=c(1, 2)) # allow 2 plots side-by-side
plot(formask, ext=e, col="dark green", legend=FALSE)
plot(formaskSieve, ext=e, col="dark green", legend=FALSE)
par(mfrow=c(1, 1)) # reset plotting window


###################################################
### code chunk number 38: Lesson_6.Rnw:536-549
###################################################
# define a weights matrix
w <- rbind(c(0, 1, 0),
           c(1, 1, 1),
           c(0, 1, 0))
print(w)
# alternatively:
w <- matrix(c(0, 1, 0, 1, 1, 1, 0, 1, 0), nrow = 3)

# prepare the sievemask (as above)
sievemask <- setValues(raster(formask), NA)
sievemask[!is.na(formask)] <- 1
# sum of all neighbouring pixels, except for diagonals
sievemask <- focal(sievemask, w = w, fun = sum, na.rm = TRUE)


###################################################
### code chunk number 39: Lesson_6.Rnw:557-566
###################################################
# copy the original forest mask
formaskSieve <- formask
# assign NA to pixels where the sievemask == 1/9
formaskSieve[sievemask == 1] <- NA
e <- extent(c(811744.8, 812764.3, 849997.8, 850920.3))
par(mfrow = c(1, 2))
plot(formask, ext = e, col = "dark green", legend = FALSE)
plot(formaskSieve, ext = e, col = "dark green", legend = FALSE)
par(mfrow = c(1, 1))


###################################################
### code chunk number 40: Lesson_6.Rnw:582-586
###################################################
data(lulcGewata)
# check out the distribution of the values
freq(lulcGewata)
hist(lulcGewata)


###################################################
### code chunk number 41: Lesson_6.Rnw:591-593
###################################################
data(LUTGewata)
LUTGewata


###################################################
### code chunk number 42: Lesson_6.Rnw:598-599
###################################################
lulc <- as.factor(lulcGewata)


###################################################
### code chunk number 43: Lesson_6.Rnw:604-607
###################################################
# assign a raster attribute table (RAT)
levels(lulc) <- LUTGewata
lulc


###################################################
### code chunk number 44: Lesson_6.Rnw:616-623
###################################################
data(tura)

# inspect the data
class(tura) # the object's class
projection(tura) # the projection
res(tura) # the spatial resolution (x, y)
extent(tura) # the extent of the raster brick


###################################################
### code chunk number 45: Lesson_6.Rnw:629-630
###################################################
names(tura) # displays the names of all layers in the tura RasterBrick


###################################################
### code chunk number 46: Lesson_6.Rnw:635-650
###################################################
# display the 1st 3 characters of the layer names
sensor <- substr(names(tura), 1, 3)
print(sensor)

# display the path and row as numeric vectors in the form (path,row)
path <- as.numeric(substr(names(tura), 4, 6))
row <- as.numeric(substr(names(tura), 7, 9))
print(paste(path, row, sep = ","))

# display the date
dates <- substr(names(tura), 10, 16)
print(dates)

# format the date in the format yyyy-mm-dd
as.Date(dates, format = "%Y%j")


###################################################
### code chunk number 47: Lesson_6.Rnw:655-666
###################################################
# ?getSceneinfo
sceneinfo <- getSceneinfo(names(tura))
print(sceneinfo)
# add a 'year' column to the sceneinfo dataframe and plot #scenes/year
sceneinfo$year <- factor(substr(sceneinfo$date, 1, 4), levels = c(1984:2013))

ggplot(data = sceneinfo, aes(x = year, fill = sensor)) + 
  geom_bar() + 
  labs(y = "number of scenes") + 
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45))


###################################################
### code chunk number 48: Lesson_6.Rnw:672-677
###################################################
ggplot(data = sceneinfo, aes(x = year, fill = sensor)) + 
  geom_bar() + 
  labs(y = "number of scenes") + 
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45))


###################################################
### code chunk number 49: Lesson_6.Rnw:694-699
###################################################
plot(tura, c(1:9))
# alternatively, you can use [[]] notation to specify layers
plot(tura[[1:9]])
# use the information from sceneinfo data.frame to clean up the titles
plot(tura[[1:9]], main = sceneinfo$date[c(1:9)])


###################################################
### code chunk number 50: Lesson_6.Rnw:705-712
###################################################
# we need to define the breaks to harmonize the scales (to make the plots comparable)
bks <- seq(0, 10000, by = 2000) # (arbitrarily) define the breaks
# we also need to redefine the colour palette to match the breaks
cols <- rev(terrain.colors(length(bks))) # col = rev(terrain.colors(255)) is the default colour palette parameter set in raster plots, but there are many more options available!
# (opt: check out the RColorBrewer package for other colour palettes)
# plot again with the new parameters
plot(tura[[1:9]], main = sceneinfo$date[1:9], breaks = bks, col = cols)


###################################################
### code chunk number 51: Lesson_6.Rnw:717-736
###################################################
library(rasterVis)
levelplot(tura[[1:6]])
# NOTE:
# for rasterVis plots we must use the [[]] notation for extracting layers

# providing titles to the layers is done using 
# the 'names.attr' argument in place of 'main'
levelplot(tura[[1:8]], names.attr = sceneinfo$date[1:8])
# define a more logical colour scale
library(RColorBrewer)
# this package has a convenient tool for defining colour palettes
# ?brewer.pal
display.brewer.all()
cols <- brewer.pal(11, 'PiYG')
# to change the colour scale in levelplot(), 
# we first have to define a rasterTheme object
# see ?rasterTheme() for more info
rtheme <- rasterTheme(region = cols)
levelplot(tura[[1:8]], names.attr = sceneinfo$date[1:8], par.settings = rtheme)


###################################################
### code chunk number 52: Lesson_6.Rnw:742-746
###################################################
# histograms of the first 6 layers
histogram(tura[[1:6]])
# box and whisker plot of the first 9 layers
bwplot(tura[[1:9]])


###################################################
### code chunk number 53: Lesson_6.Rnw:754-786
###################################################
# try for one layer first
y <- freq(tura[[1]]) # this is a matrix
y <- as.data.frame(y)
# how many NA's are there in this table?
y$count[is.na(y$value)]
# alternatively, using the with() function:
with(y, count[is.na(value)])
# as a %
with(y, count[is.na(value)]) / ncell(tura[[1]]) * 100
# apply this over all layers in the RasterBrick
# first, prepare a numeric vector to be 'filled' in
nas <- vector(mode = 'numeric', length = nlayers(tura))
for(i in 1:nlayers(tura)){
  y <- as.data.frame(freq(tura[[i]]))
  # if there are no NAs, then simply assign a zero
  # otherwise, grab the # of NAs from the frequency table
  if(!TRUE %in% is.na(y$value)){
    nas[i] <- 0
  } else {
    nas[i] <- with(y, count[is.na(value)]) / ncell(tura[[i]]) * 100
  }
}
# add this vector as a column in the sceneinfo data.frame
#(rounded to 2 decimal places)
sceneinfo$nodata <- round(nas, 2)

# plot these values
ggplot(data = sceneinfo, aes(x = date, y = nodata, shape = sensor)) +
  geom_point(size = 2) +
  labs(y = "% nodata") +
  theme_bw()



###################################################
### code chunk number 54: Lesson_6.Rnw:791-795
###################################################
ggplot(data = sceneinfo, aes(x=date, y=nodata, shape=sensor)) +
  geom_point(size = 2) +
  labs(y="% nodata") +
  theme_bw()


###################################################
### code chunk number 55: Lesson_6.Rnw:804-811
###################################################
# which layers have 100% data loss?
which(sceneinfo$nodata == 100)
# supply these indices to the dropLayer() command to get rid of these layers
tura <- dropLayer(tura, which(sceneinfo$nodata == 100))
# redefine our sceneinfo data.frame as well
sceneinfo <- sceneinfo[which(sceneinfo$nodata != 100), ]
# optional: remake the previous ggplots with this new dataframe


###################################################
### code chunk number 56: NAplot
###################################################
# calc() will apply a function over each pixel
# in this case, each pixel represents a time series of NDVI values
# e.g. all values of the 53rd pixel in the raster grid:
y <- as.numeric(tura[53])
# how many of these values have been masked (NA)?
length(y[is.na(y)])
# as a %
length(y[is.na(y)]) / length(y) * 100
# now wrap this in a calc() to apply over all pixels of the RasterBrick
nodata <- calc(tura, fun = function(x) length(x[is.na(x)]) / length(x) * 100)


###################################################
### code chunk number 57: Lesson_6.Rnw:845-847 (eval = FALSE)
###################################################
## plot(tura, 101)
## click(tura, n = 1)


###################################################
### code chunk number 58: Lesson_6.Rnw:852-864
###################################################
# several pixel coordinate pairs expressed as separate 1-row matrices
forest <- matrix(data=c(819935, 832004), nrow=1, 
                 dimnames=list(NULL, c('x', 'y')))
cropland <- matrix(data=c(819440, 829346), nrow=1, 
                   dimnames=list(NULL, c('x', 'y')))
wetland <- matrix(data = c(822432, 832076), nrow=1, 
                  dimnames=list(NULL, c('x', 'y')))

# recall that we can extract pixel data if we know the cell #
# we can easily convert from xy matrix to cell number with cellFromXY()
cellFromXY(tura, forest)
tura[cellFromXY(tura, forest)] # returns a 1-row matrix with all ts values


###################################################
### code chunk number 59: Lesson_6.Rnw:869-882
###################################################
# prepare the data.frame
ts <- data.frame(sensor = getSceneinfo(names(tura))$sensor,
                 date = getSceneinfo(names(tura))$date,
                 forest = t(tura[cellFromXY(tura, forest)]),
                 cropland = t(tura[cellFromXY(tura, cropland)]),
                 wetland = t(tura[cellFromXY(tura, wetland)])
                 )
print(ts)

# simple plot of forest time series
plot(ts$date, ts$forest)
# same thing but using with()
with(ts, plot(date, forest))


###################################################
### code chunk number 60: Lesson_6.Rnw:887-890
###################################################
# remove all data from the TM sensor and plot again
ts <- ts[which(ts$sensor != "TM"), ]
with(ts, plot(date, forest))


###################################################
### code chunk number 61: Lesson_6.Rnw:895-910
###################################################
library(reshape)
# convert dates to characters, otherwise melt() returns an error
ts$date <- as.character(ts$date)
tsmelt <- melt(ts)
head(tsmelt)
names(tsmelt) <- c('sensor', 'date', 'class', 'value')
# convert tsplot$date back to Date class to enable formatting of the plot
tsmelt$date <- as.Date(tsmelt$date)

ggplot(data = tsmelt, aes(x = date, y = value / 10000)) +
  geom_point() +
  scale_x_date() +
  labs(y = "NDVI") +
  facet_wrap(~ class, nrow = 3) +
  theme_bw()


###################################################
### code chunk number 62: Lesson_6.Rnw:916-922
###################################################
ggplot(data = tsmelt, aes(x = date, y = value / 10000)) +
  geom_point() +
  scale_x_date() +
  labs(y = "NDVI") +
  facet_wrap(~ class, nrow = 3) +
  theme_bw()


