### R code from vignette source 'Lesson_1and2_SdB.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: Lesson_1and2_SdB.Rnw:144-147
###################################################
a <- 1
a
print('Hello World')


###################################################
### code chunk number 2: Lesson_1and2_SdB.Rnw:154-156
###################################################
class(a)
class('Hello World')


###################################################
### code chunk number 3: Lesson_1and2_SdB.Rnw:163-165
###################################################
b <- 2 
a + b


###################################################
### code chunk number 4: customfunctions
###################################################
#--------------------------CUSTOM FUNCTIONS-------------------------------------

add<-function(x){ #put the function arguments in () and the evaluation in {}
  x+1
}
add(3)
add(4) 

#--Set the default values for your function--
add<-function(x=5){
  x+1
}
add() #automatically evaluates x=5
add(6) #but you can still change the defaults


###################################################
### code chunk number 5: Lesson_1and2_SdB.Rnw:194-201
###################################################
newfunc <- function(x, y) {
  2*x + y
} 

a2b <- newfunc(2, 4)
a2b
rm(a, b, newfunc, a2b)


###################################################
### code chunk number 6: Lesson_1and2_SdB.Rnw:210-211
###################################################
# ?class


###################################################
### code chunk number 7: readcsvexample
###################################################
#--------------------------READING DATA IN AND OUT------------------------------
library(rasta) ## load the rasta library
f <- system.file("extdata/kenpop89to99.csv", package="rasta") 
## make a link to the csv file within the 'rasta' package
mydat<-read.csv(f)


###################################################
### code chunk number 8: explore
###################################################
names(mydat) #colunm names

summary(mydat) #basic summary information

head(mydat) #first 6 rows

tail(mydat) # last 6 rows


###################################################
### code chunk number 9: regression
###################################################
#--------------------------REGRESSION AND LISTS------------------------------
myreg<-lm(Y99Pop~Y89Births+Y89Brate,data=mydat) #Regress the Population in 1999 on the population and birthrate in 1989
myreg


###################################################
### code chunk number 10: exploreregobject
###################################################
#--------------------------EXPLORE A REGRESSION OBJECT------------------------------

names(myreg) #get the names of the items in the regression object

summary(myreg) #print out the key information

myregsum<-summary(myreg) #create a new regression summary object

names(myregsum)

myregsum[['adj.r.squared']] #extract the adjusted r squared

myregsum$adj.r.squared #does the same thing


