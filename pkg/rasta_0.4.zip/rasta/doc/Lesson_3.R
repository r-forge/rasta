### R code from vignette source 'Lesson_3.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: Lesson_3.Rnw:107-118
###################################################
# Create two rastersLayer objects of similar extent
library(raster)
r <- s <- raster(ncol=50, nrow=50)
# fill the raster with values
r[] <- 1:ncell(r)
s[] <- 2 * (1:ncell(s))
s[200:400] <- 150
s[50:150] <- 151
# perform the replacement
r[s %in% c(150, 151)] <- NA
# Visualize the result


###################################################
### code chunk number 2: raster-1
###################################################
plot(r)


###################################################
### code chunk number 3: Lesson_3.Rnw:137-142
###################################################
# Imports the variable cars in the working environment
data(cars) 
class(cars)
# Visualizes the first five rows of the variable
head(cars) 


###################################################
### code chunk number 4: cars
###################################################
# The plot function on this type of dataset (class = data.frame, 2 column)
# automatically generates a scatterplot
plot(cars)


###################################################
### code chunk number 5: Lesson_3.Rnw:161-170
###################################################
## Example using built-in dataset from the sp package
library(sp)
# Load required datastes
data(meuse)
# The meuse dataset is not by default a spatial object
# but its x, y coordinates are part of the data.frame
class(meuse)
coordinates(meuse) <- c("x", "y")
class(meuse)


###################################################
### code chunk number 6: meuse1
###################################################
bubble(meuse, "zinc", maxsize = 2.5,
       main = "zic concentrations (ppm)", key.entries = 2^(-1:4))


###################################################
### code chunk number 7: meuse2
###################################################
# Load meuse.riv dataset
data(meuse.riv)
# Create an object of class spatialPolygons from meuse.riv
meuse.sr <- SpatialPolygons(list(Polygons(list(Polygon(meuse.riv)),"meuse.riv")))
# Load the meuse.grid dataset
data(meuse.grid)
# Assign coordinates to the dataset and make it a grid
coordinates(meuse.grid) = c("x", "y")
gridded(meuse.grid) = TRUE
# Plot all variables of the meuse.grid dataset in a multiple window spplot
spplot(meuse.grid, col.regions=bpy.colors(), main = "meuse.grid",
  sp.layout=list(
  list("sp.polygons", meuse.sr),
	list("sp.points", meuse, pch="+", col="black")
  )
)


###################################################
### code chunk number 8: Lesson_3.Rnw:258-274
###################################################
# 5 different objects belonging to 5 different classes
a <- 12
class(a)

b <- "I have a class too"
class(b)

library(raster)
c <- raster(ncol=10, nrow=10)
class(c)

d <- stack(c, c)
class(d)

e <- brick(d)
class(e)


###################################################
### code chunk number 9: Lesson_3.Rnw:282-289
###################################################
HelloWorld <- function (x) {
  hello <- sprintf('Hello %s', x)
  return(hello)
}

# Let's test it
HelloWorld('john')


###################################################
### code chunk number 10: Lesson_3.Rnw:295-306
###################################################
HelloWorld <- function (x) {
  if (is.character(x)) {
    hello <- sprintf('Hello %s', x)
  } else {
    hello <- warning('Object of class character expected for x')
  }
  return(hello)
}

HelloWorld(21)



###################################################
### code chunk number 11: Lesson_3.Rnw:314-320
###################################################
is.character('john')
# is equivalent to 
class('john') == 'character'

is.character(32)
is.numeric(32)


###################################################
### code chunk number 12: Lesson_3.Rnw:325-347
###################################################
library(raster)
# Function to substract 2 rasterLayers
minusRaster <- function(x, y, plot=FALSE) { 
  z <- x - y
  if (plot) {
    plot(z)
  }
  return(z)
}

# Let's generate 2 rasters 
# that first one is the R logo raster
# converted to the raster package file format.
r <- raster(system.file("external/rlogo.grd", package="raster")) 
# The second RasterLayer is calqued from the initial RasterLayer in order
# to avoid issues of non matching extent or resolution, etc
r2 <- r 
# Filling the rasterLayer with new values.
# The /10 simply makes the result more spectacular
r2[] <- (1:ncell(r2)) / 10
# simply performs the calculation
r3 <- minusRaster(r, r2) 


###################################################
### code chunk number 13: minus
###################################################
# Now performs the claculation and plots the resulting RasterLayer
r4 <- minusRaster(r, r2, plot=TRUE) 


###################################################
### code chunk number 14: a
###################################################
library(raster)

# Create a raster layer and fill it with "randomly" generated integer values
a <- raster(nrow=50, ncol=50)
a[] <- floor(rnorm(n=ncell(a)))

# The freq() function returns the frequency of a certain value in a RasterLayer
freq(a, value=-2)

# Let's imagine that you want to run this function over a whole list of RasterLayer
# but some elements of the list are impredictibly corrupted
# so the list looks as follows
b <- a
c <- NA
list <- c(a,b,c)
# In that case, b and a are raster layers, c is ''corrupted''


###################################################
### code chunk number 15: a (eval = FALSE)
###################################################
## # Running freq(c) would return an error and crash the whole process
## out <- list()
## for(i in 1:length(list)) {
##   out[i] <- freq(list[[i]], value=-2)
## }


###################################################
### code chunk number 16: Lesson_3.Rnw:394-417
###################################################
# Therefore by building a function that includes a try()
# we are able to catch the error
# allowing the process to continue despite missing/corrupted data.
fun <- function(x, value) {
  tr <- try(freq(x=x, value=value), silent=TRUE)
  if (class(tr) == 'try-error') {
    return('This object returned an error')
  } else {
    return(tr)
  }
}

# Let's try to run the loop again
out <- list()
for(i in 1:length(list)) {
  out[i] <- fun(list[[i]], value=-2)
}
out

# Note that using a function of the apply family would be a more
# elegant/shorter way to obtain the same result
(out <- sapply(X=list, FUN=fun, value=-2))



###################################################
### code chunk number 17: Lesson_3.Rnw:538-557
###################################################
is.leap <- function(x) {
  if (!class(x) == 'numeric') {
    stop('argument of class numeric expected')
  }
  if (x > 1582) {
    if (x %% 400 == 0) {
      a <- TRUE
    } else if (x %% 100 == 0) {
      a <- FALSE
    } else if (x %% 4 == 0) {
      a <- TRUE
    } else {
      a <- FALSE
    }
  } else {
    a <- sprintf('%d is out of the valid range', x)
  }
  return(a)
}


###################################################
### code chunk number 18: Lesson_3.Rnw:560-566
###################################################
is.leap(2000)
is.leap(1581)
is.leap(2002)

#is.leap('john') should return an error 
#error: argument of class numeric expected


